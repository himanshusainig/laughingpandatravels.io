<!DOCTYPE html>
<html lang="en">
<head>
      <style>

    /* Default styles for the button 
#Guests  {
   margin-right:487px;
    margin-left:457px;
    margin-top:26px;
    border-radius:10px;
    font-size:25px;
    background-color:#ffc107;
    margin-bottom:-12px;
}
*/
/* Media query for smaller screens */
@media only screen and (max-width: 600px) {
    .gues {
        margin-right: 35px; /* Adjust margin-right for smaller screens */
        margin-left: 35px;
        font-size:xx-large;
             padding-left:36px;/* Adjust margin-left for smaller screens */
    }
}

.touch {
    margin-right: 21px; /* Adjust margin-right for larger screens */
    margin-left: auto; /* Align to the right */
    margin-top: 26px;
    border-radius: 10px;
    font-size: 25px;
    background-color: #ffc107;
    margin-bottom: -12px;
    cursor: pointer;
    transition: transform 0.2s;
    display: inline-block; /* Ensure the text doesn't take full width */
}

/* Media query for smaller screens */
@media only screen and (max-width: 600px) {
    .touch {
        margin-right: 21px; /* Adjust margin-right for smaller screens */
        margin-left: auto; /* Align to the right */
        font-size: xx-large;
        padding-left: 36px;
        margin-top: 26px; /* Adjust margin-top for smaller screens */
    }
}

.touch:hover {
    transform: translateX(5px);
}

    
    
    
    .temp{
        font-size:medium;
          margin-top:9px;
          color:white;
    }
    
    .tempimg{
     
      width:200px;
    
    }
   
.ban-short-links{
     MARGIN-TOP: 12PX;
    background-color: #ffffff;
    margin-left: -16px;
    margin-right: 185px;
    border-radius:10px;
     width: 100%;
    text-align: center;
    
}
* {
  box-sizing: border-box;
}


.service:hover {
  -ms-transform: scale(1.5); /* IE 9 */
  -webkit-transform: scale(1.5); /* Safari 3-8 */
  transform: scale(1.5); 
   background-color: green;
}

.service {
     transition: transform .2s;
    border: 1px solid #ccc;
    padding: 10px;
    display: inline-block; /* This ensures each service is displayed in a line */
  margin: 0 10px 10px 0; 
    background-color:#6c757d;/* Adjust margin as needed */
     box-sizing: border-box;
     margin-top:10px;
     border-radius:10px;
     width:180px;
      
}

.service img {
    max-width: 100%; /* Ensure images don't exceed container width */
    height: auto; /* Maintain aspect ratio */
}

.service h4 {
    margin: 10px 0 5px; /* Add margin top and bottom */
}


@media only screen and (max-width: 600px) {
    .service {
        width: calc(50% - 20px); /* Adjust width to fit two services per row */
        margin-right: 10px; /* Add margin to create space between services */
        margin-bottom: 10px; /* Add margin to create space between rows */
    }
}

    
        .split {
            height: 100%;
            width: 50%;
            position: fixed;
            z-index: 1;
            top: 0;
            overflow-x: hidden;
            padding-top: 20px;
            display: none;
        }

        .show-contact-form .split.right {
            display: block;
        }

        .right {
            right: -202px;
            position: absolute;
            margin-top: 127px;
            margin-right: -109px;
        }

        /* New CSS for mobile */
        @media (max-width: 768px) {
            .split {
                width: 100%;
                height: 50%;
                top: unset;
                bottom: -100%;
                padding-top: 0;
                padding-bottom: 20px;
            }

            .show-contact-form .split.right {
                bottom: 0;
            }

            .right {
                right: 0;
                margin-top: unset;
                margin-right: unset;
            }
        }


        .pagination-container {

            justify-content: space-between;
            margin-left: 459px;
            margin-top: 10px;
            /* Adjust this value as needed */
        }

        .prev-btn,
        .next-btn {
            border-radius: 11px;
            background-color: #ffc107;
            padding: 5px 10px;
            /* Add padding to buttons for better spacing */
        }

        /* Media query for mobile devices */
        @media (max-width: 768px) {
            .pagination-container {
                justify-content: center;
                margin-left: 0;
                display: flex;


            }
        }

        h3.one {
            border-style: solid;
            border-width: 2px;
            margin-right: 461px;
            padding-left: 33px;
            font-size: x-large;
            border-radius: 26px;
            background-color: paleturquoise;
        }

        @media (max-width: 767px) {
            h3.one {
             
                /* Remove the right margin */
                margin-bottom: 15px;
               
               
                 margin-right: 0 !important;
                margin-left: 0 !important;
                /* Add some bottom margin for spacing */
            }
        }
        
            @media (max-width: 767px) {
           p.three {
                 margin-right: 0 !important;
            margin-left: 0 !important;
            }
        }

        .horizontal-align {
            display: inline-block;
            white-space: nowrap;
            margin-left: -53px;
            margin-top: 6px;
        }
        
        .two {
        margin-top: 39px;
        margin-left: 21px;
        display: flex;
        align-items: center;
        border-style: solid;
        border-width: 2px;
        margin-right: 15px; /* Adjusted margin-right for mobile */
        padding-left: 33px;
        font-size: large; /* Adjusted font size for mobile */
        border-radius: 26px;
        background-color: paleturquoise;
    }

      @media (max-width: 768px) {
        .two {
            margin-right: 0 !important;
            margin-left: 0 !important;
        }
    }
    
    .modal-title {
    font-size: large;
    
    border-radius: 4px;
}

#saveReview:hover {
    background-color: red !important; /* Change the color to your desired hover color */
}


/* by anurag why templemitra.com in index page */

    
        .cus {
            color: white;
        }

        .carousel-horizontal .carousel-inner .item {
            flex: 0 0 auto;
            width: 100%;
        }

        .carousel-horizontal .carousel-inner .item img {
            max-width: 100%;
            height: auto;

        }

        .carousel {
            display: flex;
            overflow: hidden;
        }

        .carousel .carousel-inner {
            display: flex;
            transition: transform 0.5s ease;
        }

        .carousel .item {
            flex: 0 0 auto;
            width: 100%;
        }

        .carousel-container {
            position: relative;
            overflow: hidden;

        }

        .carousel-inner {
            display: flex;
            transition: transform 0.5s ease;
        }

        .item {
            flex: 0 0 100%;
        }

        .carousel-control {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(0, 0, 0, 0.5);
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
        }

        .carousel-control.prev {
            left: 0;
        }

        .carousel-control.next {
            right: 0;
        }

        .why-newbox {
            display: flex;
            flex-wrap: wrap;
            margin-left: -143px;
            background-color: white;
            border-radius: 5px;

        }

        .why-newbox li {
            width: calc(33.33% - 20px);
            /* 33.33% for three items per row and subtracting margin */
            margin-bottom: 20px;
            text-align: center;

            border: 2px solid #343a40;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.5);
            list-style-type: none;
            height: 150px;
            border-radius: 10px;
            /* Adding a border for better visibility */
        }

        @media (max-width: 768px) {
            .why-newbox {
            display: flex;
            flex-wrap: wrap;
            margin-left: 0; /* Remove the negative margin */
            padding: 0 10px; /* Add padding to the container for spacing */
            }
            
            .why-newbox li {
            width: calc(50% - 20px); /* Adjusted width to consider margins */
            margin: 10px; /* Add margin on all sides of each item */
            box-sizing: border-box; /* Include padding and border in the width calculation */
            }
            }
    
    /* by anurag why abous us payment  */
            .button-container {
            border: 1px solid black;
            border-radius: 15px;
            display: flex;
            padding: 10px;
            width: fit-content;
            cursor: pointer;
        }

        .text-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-left: 10px;
            justify-content: center;
            margin-right: 10px;
        }

        .logo-container {
            width: 40px;
            height: 40px;
        }

        .seconday-logo-container {
            width: 16px;
            height: 16px;
            vertical-align: middle;
        }

        a {
            text-decoration: none;
        }
        
   .ban {
    margin-top: -35px;
    color: white;
    font-size: 40px;
    border-radius: 30px;
    border: 2px solid;
    margin-right: auto;
    margin-left: auto;
    max-width: 20%; 
    background-color: black;/* Set a maximum width to ensure responsiveness */
}

/* Media query for mobile devices */
@media (max-width: 768px) {
    .ban {
        font-size: 28px; 
         max-width: 50%;/* Adjust font size for smaller screens */
    }
}

.ban1{
   margin-top:8px;
   margin-left:73px;
}
@media (max-width: 768px) {
    .ban1 {
       margin-top: -13px;
       margin-left:-3px;
    /* Adjust font size for smaller screens */
    }
}

@media (max-width: 768px) {
    .details-container {
       margin-left:-42px;
        /* Adjust font size for smaller screens */
    }
}

@media (max-width: 768px) {
    .btn3 {
       margin-left:-42px;
        /* Adjust font size for smaller screens */
    }
}




/*  group packages css by anurag start */

 
        .package-info {
            padding: 15px;
        }

        .chardham-group-heading {
            margin-top:60px;
            color: black;
            font-size: 30px;
            border-radius: 30px;
            /*border: 2px solid;*/
            margin-right: auto;
            margin-left: auto;
            max-width: 100%;
            /*background-color: black;*/
            text-align: center;
        }

        .date-container {
            position: relative;
            display: inline-block;
            margin: 10px;
            cursor: pointer;
        }

        .avroom {
            background-color: green;
            color: yellow;
            border-radius: 2px;
            padding: 2px 4px;
        }

        .avroom:hover {
            text-decoration: underline;
            color: black;
        }

        .control-buttons {
            justify-content: space-between;
            align-items: center;

        }

        .control-buttons button {
            font-size: 16px;
            margin: -7px 8px;
        }

        .package-info table {
            width: 100%;
            border-collapse: collapse;
        }

        .package-info th,
        .package-info td {
            padding: 8px;
            border: 1px solid #ddd;
            background-color: #343a40;
            color: white;
            text-align: center;

        }

        @media (max-width: 480px) {

            .package-info th,
            .package-info td {
                padding: 8px;
                border: 1px solid #ddd;
                background-color: #343a40;
                color: white;
                text-align: center;
                width: 27%;
            }
        }


        .package-info th {
            background-color: black;
            color: white;
        }

        .package-info tr:nth-child(even) {
            background-color: #333;
        }

        .package-info tr:hover {
            background-color: white;
        }

        .group-date {
            border-radius: 4px;
            display: flex;
            justify-content: space-between;
            text-align: center;
            flex-wrap: wrap;
            background-color: black;
            color: white;
            margin: 25px 6px;
        }
        
            .group-date-amrnath {
            border-radius: 4px;
            display: flex;
            /*justify-content: space-between;*/
            text-align: center;
            flex-wrap: wrap;
            background-color: black;
            color: white;
            margin: 25px 6px;
        }


        /* New Button Styles */
        .button-pay-summary {
            text-align: right;
            margin-top: 20px;
            /*display: flex;*/
            justify-content: space-around;
        }

        .button-pay-summary button {
            padding: 4px 8px;
            background-color: green;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-left: 10px;
            margin: 2px;

            /* Add space between buttons */
        }

        .button-pay-summary button:hover {
            background-color: #45a049;
        }

        .contact-info-summary {
            float: left;
            color: #d9dbe4;
            background-color: #000000;
            padding: 4px 8px;
            border-radius: 4px;
        }



        /* Modal Styling */
        .modal-group {
            display: none;
            /* Hide modal initially */
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            /* Semi-transparent background */
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .modal-content-group {
            background-color: green;
            padding: 10px;
            border-radius: 8px;
            width: 90%;
            max-width: 800px;
            border: 1px solid;
            box-shadow: 1px 1px 1px #bf1212;
            position: relative;
            overflow: hidden;
        }

        /* Header section */
        .modal-header-group {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .modal-header-group h4 {
            margin: 0;
            color: white;
            font-size: 24px;
            margin-left: 18rem;
        }



        @media screen and (max-width: 600px) {
            .modal-header-group h4 {
                margin: 0;
                color: white;
                font-size: 24px;
                margin-left: 9rem;

            }
        }

        .close-btn {
            background-color: #ff4d4d;
            color: white;
            border: none;
            padding: 4px 8px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
        }

        .close-btn:hover {
            background-color: #ff1a1a;
        }

        /* Table Styling */
        .booking-table {
            width: 100%;
            border-collapse: collapse;
        }

        .booking-table th,
        .booking-table td {
            /*padding: 10px;*/
            border: 1px solid black;
            background-color: #f4f4f4;
            text-align: center;

        }

        .booking-table th {
            background-color: black;
            color: white;
        }

        .booking-table tr:nth-child(even) {
            background-color: #e9ecef;
        }

        .booking-table tr:hover {
            background-color: #ddd;
        }


        /* Footer and Button Styling */
        .button-pay-summary {
            text-align: right;
            margin-top: 20px;
        }

        .pay-btn {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
        }

        .pay-btn:hover {
            background-color: #218838;
        }

        /* Responsiveness */
        @media screen and (max-width: 600px) {
            .modal-content-group {
                width: 95%;
                padding: 15px;
            }

            .booking-table th,
            .booking-table td {
                font-size: 14px;
            }

            .close-btn,
            .pay-btn {
                padding: 6px 12px;
                font-size: 14px;
            }
        }
  
  .ico-bg-group {
background-color: #0c63af;
color: #fff;
width: 40px;
padding-left: 13px;

}

.bg-primary-group{
    background-color:green;
    color: white
}



.modal-content-pay {
    position: relative;
    display: -ms-flexbox;
    display: flex
;
    -ms-flex-direction: column;
    flex-direction: column;
    width: 100%;
    pointer-events: auto;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid rgba(0, 0, 0, .2);
    border-radius: .3rem;
    outline: 0;
    margin-top:7rem;
}

.selected-date {
    color: red;
    font-weight: bold;
}


* {
  box-sizing: border-box;
}

/* Create three equal columns that floats next to each other */
.column-notes-group {
 float: left;
    /* width: 33.33%; */
    /* padding: 42px; */
    color: white;
    margin: 14px 42px;
}

.row-notes-group{
    border-radius:5px;
    margin-top:0rem;
    background-color: blue;
    box-shadow: 1px 1px 1px #bf1212;
}

/* Clear floats after the columns */
.row-notes-group:after {
  content: "";
  display: table;
  clear: both;
}

.dep-heading{
    margin-top:15px;
    text-align: left;
}


   @media only screen and (max-width: 768px) {
        .column-notes-group {
            width: 100%;
            /* Make the columns stack vertically on smaller screens */
            padding: 4px;
            font-size: 16px;
            margin: 0px 0px;
            /* Optional: adjust padding for mobile */
            text-align: center;
            /* Center the text on mobile */
        }

        .row-notes-group {
            margin-top: 0;
            /* Optional: Adjust margin for mobile */
        }
    }
    
       @media only screen and (max-width: 480px) {
        .column-notes-group {
            padding: 3px;
            font-size: 16px;
            margin: 0px 0px;
            /* Adjust padding further for small screens */
        }
    }

.pdate{
    color:red;
    /*margin-top:-1rem;*/
}



/*  group packages css by anurag end */


   /*youtube video css start */

   /* Container for the slider */
        .youtube-slider-container {
            position: relative;
            width: 100%;
            max-width: 800px;
            margin: auto;
        }

        /* Hide all videos by default */
        .youtube-video-slide {
            display: none;
        }

        /* Style for the buttons (next and previous) */
        .youtube-prev, .youtube-next {
            position: absolute;
            top: 50%;
            padding: 16px;
            font-size: 18px;
            color: white;
            background-color: rgba(0, 0, 0, 0.5);
            border: none;
            cursor: pointer;
            border-radius: 50%;
        }

        .youtube-prev {
            left: 10px;
            transform: translateY(-50%);
        }

        .youtube-next {
            right: 10px;
            transform: translateY(-50%);
        }

        /* Hover effect for the buttons */
        .youtube-prev:hover, .youtube-next:hover {
            background-color: rgba(0, 0, 0, 0.8);
        }


   /*youtube video css end */

</style>
    
     <title> Privacy Policy</title>
     <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!--  favicon -->
<link rel="shortcut icon" href="https://templemitra.com/files/assets/images/icn/fav-icon.png" type="image/x-icon">
<link rel="icon" href="https://templemitra.com/files/assets/images/icn/fav-icon.png" type="image/x-icon" type="image/x-icon">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<!--    external-->
<link href="https://templemitra.com/files/assets/css/navmenu.css" rel="stylesheet" type="text/css">
<link href="https://templemitra.com/files/assets/css/external.css" rel="stylesheet" type="text/css">
<link href="https://templemitra.com/files/assets/css/external-modal.css" rel="stylesheet" type="text/css">
<link href="https://templemitra.com/files/assets/css/form-input.css" rel="stylesheet" type="text/css">
<!-- animation nifty modal window effects css -->
<link href="https://templemitra.com/files/assets/css/component.css" rel="stylesheet" type="text/css">
<!--  =====disable Disable Ctrl+A,Ctrl+C key functions to HTMl page==========  --> 







<!-- <script>
    function ieClicked() {
        if (document.all) {
            return false;
        }
    }

    function firefoxClicked(e) {
        if (document.layers || (document.getElementById && !document.all)) {
            if (e.which == 2 || e.which == 3) {
                return false;
            }
        }
    }
    if (document.layers) {
        document.captureEvents(Event.MOUSEDOWN);
        document.onmousedown = firefoxClicked;
    } else {
        document.onmouseup = firefoxClicked;
        document.oncontextmenu = ieClicked;
    }
    document.oncontextmenu = new Function("return false")

    function disableselect(e) {
        return false
    }

    function reEnable() {
        return true
    }
    document.onselectstart = new Function("return false")
    if (window.sidebar) {
        document.onmousedown = disableselect
        document.onclick = reEnable
    }
</script> -->



<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-DTKTX80HDC"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-DTKTX80HDC');
</script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-104332405-2"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'UA-104332405-2');
</script>
<!-- Global site tag (gtag.js) - Google Ads: 823141097 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-823141097"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'AW-823141097');
</script>
<script>
window.addEventListener('load',function(){
if(window.location.pathname.indexOf('/thank-you.php')!=-1){
  gtag('event', 'conversion', {'send_to': 'AW-332442045/upHxCKnJlZUDEL3Twp4B'});
}
})
</script>
<!-- Event snippet for Lead Conversions conversion page
In your html page, add the snippet and call gtag_report_conversion when someone clicks on the chosen link or button. -->
<script>
    function gtag_report_conversion(url) {
        var callback = function() {
            if (typeof(url) != 'undefined') {
                window.location = url;
            }
        };
        gtag('event', 'conversion', {
            'send_to': 'AW-823141097/yEnWCMe406gBEOnFwIgD',
            'event_callback': callback
        });
        return false;
    }
</script>
<!-- ========chat=============-->
<!--Start of Tawk.to Script
<script>
    var Tawk_API = Tawk_API || {},
        Tawk_LoadStart = new Date();
    (function() {
        var s1 = document.createElement("script"),
            s0 = document.getElementsByTagName("script")[0];
        s1.async = true;
        s1.src = 'https://embed.tawk.to/598b6c55dbb01a218b4db96a/default';
        s1.charset = 'UTF-8';
        s1.setAttribute('crossorigin', '*');
        s0.parentNode.insertBefore(s1, s0);
    })();
</script>
<!--End of Tawk.to Script-->
<script>
    (function() {
        function loadTawkToScript() {
            var s1 = document.createElement("script"),
                s0 = document.getElementsByTagName("script")[0];
            s1.async = true;
            s1.src = 'https://embed.tawk.to/598b6c55dbb01a218b4db96a/default';
            s1.charset = 'UTF-8';
            s1.setAttribute('crossorigin', '*');
            s0.parentNode.insertBefore(s1, s0);
        }

        // Function to check if the device is a mobile device
        function isDesktop() {
            return window.innerWidth >= 768; // Adjust the width as needed
        }

        // Check if the device is a desktop before loading the script
        if (isDesktop()) {
            loadTawkToScript();
        }

        // Optionally, you can handle resizing to add/remove the chat widget dynamically
        window.addEventListener('resize', function() {
            if (isDesktop()) {
                if (!document.querySelector('script[src="https://embed.tawk.to/598b6c55dbb01a218b4db96a/default"]')) {
                    loadTawkToScript();
                }
            } else {
                var tawkScript = document.querySelector('script[src="https://embed.tawk.to/598b6c55dbb01a218b4db96a/default"]');
                if (tawkScript) {
                    tawkScript.parentNode.removeChild(tawkScript);
                }
            }
        });
    })();
</script>




<script type='application/ld+json'> 
{
  "@context": "http://www.schema.org",
  "@type": "WebSite",
  "name": "templemitra.com",
  "alternateName": "templemitra.com",
  "url": "https://templemitra.com/"
}
 </script>
<!-- this is update 1 November 2023  according to vivek sir -->
<script>
    (function(w){
        var k="nudgify",n=w[k]||(w[k]={});
        n.uuid="15b4d3f3-f110-48c3-b74d-b75111e9c65f";
        var d=document,s=d.createElement("script");
        s.src="https://pixel.nudgify.com/pixel.js";
        s.async=1;
        s.charset="utf-8";
        d.getElementsByTagName("head")[0].appendChild(s)
    })(window)
</script>
<!--this update on 8th Nov-->
<!-- Google tag (gtag.js) --> <script async src="https://www.googletagmanager.com/gtag/js?id=AW-11091917885"></script>
<script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'AW-11091917885'); </script>

<!--another on same date -->

<!-- Google tag (gtag.js) --> 
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-380523759"></script>
<script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'AW-380523759'); </script>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11091137404"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-11091137404');
</script>


<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11279859446"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-11279859446');
</script>


<!--update-- today code start here-->

<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11338038065"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-11338038065');
</script>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11279823976"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-11279823976');
</script>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11395584087"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-11395584087');
</script>

     
     <script>
         function showModal(modalId) {
    var modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('md-show');
    }
}

     </script>
</head>

<body class="freez">
     <style>
        .btn-call1 {
      color: white;
      display: flex;
      position: fixed;
      bottom: 150px;
      /* Adjust based on the height of your other elements */
      left: 0;
      right: 0;
      margin: 0 15px;
      /* Add some margin on the sides */
      z-index: 9999;
      /* Ensure it stays on top of other content */
      border-radius: 50px;
      width: 50%;
     margin-left: 330px;
    margin-bottom: -180px;
      /* Rounded corners for a more button-like appearance */
    }

    /* Ensure it's only visible on mobile devices */
    @media (min-width: 768px) {
      .btn-call1 {
        display: none;
      }
    }

    /* Adjust the button icon spacing */
    .btn-call1 i {
      margin-right: 5px;
    }
    .wtp-chat1 span {
    display: block;
    position: absolute;
    margin-top: -28px;
    z-index: -1;
    background: #27b033;
    padding: 4px 8px 4px 8px;
    margin-left: -35px;
    font-size: 20px;
    border-radius: 20px;
    color: white;
    /*width: 119px;*/
}
  .wtp-chat1 img {
        z-index: 999;
        width: 50px;
         margin-bottom: 82px;
         margin-left: 10px;
    }
    
</style>

<!-- Ads conversion tracking implementation-->

<!-- Taboola Pixel Code -->
<script type='text/javascript'>
  window._tfa = window._tfa || [];
  window._tfa.push({notify: 'event', name: 'page_view', id: 1807114});
  !function (t, f, a, x) {
         if (!document.getElementById(x)) {
            t.async = 1;t.src = a;t.id=x;f.parentNode.insertBefore(t, f);
         }
  }(document.createElement('script'),
  document.getElementsByTagName('script')[0],
  '//cdn.taboola.com/libtrc/unip/1807114/tfa.js',
  'tb_tfa_script');
</script>
<!-- End of Taboola Pixel Code -->

<script>
  window.addEventListener('load', function() {
    if (document.location.pathname.includes('/chardham-tour-package')) {
      document.addEventListener('click', function(e) {
        if (e.target.closest('button') && e.target.closest('button[type="submit"]')) {
          var timer = setInterval(function() {
            if (document.querySelector('.enquiry_success') && document.querySelector('.enquiry_success').innerText.includes('Sent')) {
              gtag('event', 'conversion', {
      'send_to': 'AW-16817587258/ZiM8CKDe1oYaELqIoNM-'});
              clearInterval(timer)
            }
          }, 1000)
        }
      })
    }
  });
</script>

<div class="top-fixed bg-theme text-light nav-radius">
  <div class="row pt-1 pb-1 m-0">
    <div class="col-xl-2 col-md-2 col-sm-2 col-5 m-0 p-0">
      <a class="" href="https://templemitra.com/">
        <img class="img-fluid img-logo-wth p-1" src="https://templemitra.com/files/assets/images/logo.png" alt="Theme-Logo">
      </a>
    </div>
    <div class="col-xl-4 col-md-3 col-sm-3 col-8 hidden-xs m-0 p-0 ">
      <!--      <input type="text" class="form-search"> -->
      <div class="form-search">
        <input type="text" autocomplete="off" id="search" class="textbox" placeholder="Search Packages..." tabindex="1">
        <img class="serc-alt" src="https://templemitra.com//files/assets/images/loading.gif" alt="loging gif">
        <i class="fas fa-times-circle cross"></i>
        <div id="livesearch"></div>
      </div>

    </div>
    <div class="col-xl-6 col-md-7 col-sm-7 col-7 m-0 p-0 mt-2">
      <a href="tel:07678398674" class="teli-m"><i class="fas fa-phone-volume"></i> +91-7678398674</a>
      <span class="btn btn-sm text-light payonline" data-toggle="modal" data-target="#PayModal"><span class="hide">Online</span> Payment</span>
      <a class="card-w" href="https://templemitra.com/458/632/895/568/Wish-List">
        <i class="fas fa-cart-plus f-45 text-success"></i>
        <i id="cart-container" class="fas fa-heart badge badge-light">
          0        </i>
      </a>
      <span class="r-email-top"><i class="fas fa-envelope-open-text hide"></i> &#105;&#110;&#102;&#111;&#064;&#116;&#101;&#109;&#112;&#108;&#101;&#109;&#105;&#116;&#114;&#097;&#046;&#099;&#111;&#109; </span>

      <!--   enquiry -->
      <div class="enq-outer md-trigger" data-modal="modal-10">
        <span class="inq-in enq " my-package="Enquiry From Circle" data-back="Back" data-front="Front">Enquiry</span>
      </div>
  <div class="d-block d-md-none mb-3 wtp-chat1">
                    <a href="tel:+918851694514" class="btn-call1 btn-icon-social">
                         <span>CALL </span>
                        <img class="" src="https://templemitra.com/files/assets/images/c.jpg" alt="whats'app templemitra">
                    </a>
                </div>

    </div>
  </div>
  <nav id="myHeader" class="navbar navbar-expand-lg navbar-light sticky-top start-header p-0">
    <div class="container-fluid">
      <a class="navbar-brand text-light pl-md-2" href="https://templemitra.com/">
        <i class="fas fa-house-user mb-1"></i>
      </a>
      <button class="navbar-toggler" onclick="closeNav(),mynave()" type="button" data-toggle="collapse" data-target="#mobile_nav" aria-controls="mobile_nav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="mobile_nav">
        <ul class="navbar-nav navbar-left">


                      <!-- for big menu  -->
            <!--========-->
            <li class="nav-item dropdown megamenu-li dmenu">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span onclick="location.href='https://templemitra.com/temple-tour-packages';"> Temple Tour Packages</span>
              </a>
              <div class="dropdown-menu megamenu sm-menu border-top" aria-labelledby="dropdown01">
                <div class="row m-0">
                  <div class="col-sm-9">
                    <div class="row m-0">
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/amarnath-yatra-packages"><i class="far fa-star m-icon"></i> Amarnath Yatra Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/ayodhya-tour-packages"><i class="far fa-star m-icon"></i> Ayodhya Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/badrinath-tour-packages"><i class="far fa-star m-icon"></i> Badrinath Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/buddhist-tour-package"><i class="far fa-star m-icon"></i> Buddhist Tour Package</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/chardham-yatra-packages"><i class="far fa-star m-icon"></i> Chardham Yatra Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/chitrakoot-tour-packages"><i class="far fa-star m-icon"></i> Chitrakoot Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/dwarkadheesh-tour-packages"><i class="far fa-star m-icon"></i> Dwarkadheesh Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/gujarat-tour-packages"><i class="far fa-star m-icon"></i> Gujarat Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/haridwar-tour-packages"><i class="far fa-star m-icon"></i> Haridwar Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/jagannath-puri-tour-packages"><i class="far fa-star m-icon"></i> Jagannath Puri Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/jyotirlingas-tour-packages"><i class="far fa-star m-icon"></i> Jyotirlingas Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/kashi-vishwanath-tour-packages"><i class="far fa-star m-icon"></i> Kashi Vishwanath Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/kedarnath-tour-packages"><i class="far fa-star m-icon"></i> Kedarnath Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/maihar-devi-tour-packages"><i class="far fa-star m-icon"></i> Maihar Devi Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/mathura-tour-packages"><i class="far fa-star m-icon"></i> Mathura Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/ramayana-tour-packages"><i class="far fa-star m-icon"></i> Ramayana Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/shirdi-tour-packages"><i class="far fa-star m-icon"></i> Shirdi Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/somnath-jyotirlingas-tour-package"><i class="far fa-star m-icon"></i> Somnath Jyotirlingas Tour Package</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/south-india-temple-tour-package"><i class="far fa-star m-icon"></i> South India Temple Tour Package</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/srisailam-tour-packages"><i class="far fa-star m-icon"></i> Srisailam Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/tirupati-balaji-tour-package"><i class="far fa-star m-icon"></i> Tirupati Balaji Tour Package</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/ujjain-mahakaleshwar-package"><i class="far fa-star m-icon"></i> Ujjain Mahakaleshwar Package</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/vaishno-devi-tour-package"><i class="far fa-star m-icon"></i> Vaishno Devi Tour Package</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/varanasi-tour-packages"><i class="far fa-star m-icon"></i> Varanasi Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/vindhyachal-tour-packages"><i class="far fa-star m-icon"></i> Vindhyachal Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/temple-tour-packages/vrindavan-tour-packages"><i class="far fa-star m-icon"></i> Vrindavan Tour Packages</a>
                        </div>
                                          </div>
                  </div>
                  <div class="col-sm-3 hide">
                    <div class="topm_carousel">
                      <div id="carouselExampleControlsm" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                          <div class="carousel-item active ">
                            <img src="https://templemitra.com/files/assets/images/p-slide/chardham-yatra-package.png" class="img-fluid couple" alt="Make Your journey Happier">
                            <a class="text-light" target="_blank" href="http://chardhampackageonline.com/Char-Dham-Group-Departure-EX-Delhi.php">
                              <div class="carousel-caption bg-scroll">
                                     <h3>Chardham Group Departure EX-Delhi (2025) <br> INR: 22,500</h3>
                                <p>(02-May, 09-May, 16-May, 23-May, 30-May, 03-June & 07- June)</p>
                              </div>
                            </a>
                          </div>
                          <div class="carousel-item">
                            <img src="https://templemitra.com/files/assets/images/p-slide/chardham-yatra-package.png" class="img-fluid couple" alt="Make Your journey Happier">

                            <a class="text-light" href="http://chardhampackageonline.com/Char-Dham-Group-Departure-EX-Haridwar.php" target="_blank">
                              <div class="carousel-caption bg-scroll">
                                <h3>Chardham Group Departure EX-Haridwar (2025) <br> INR: 19,500</h3>
                                <p>(03-May, 10-May, 17-May, 24-May, 31-May, 04-June & 08- June)</p>
                              </div>
                            </a>
                          </div>
                          <div class="carousel-item">
                            <img src="https://templemitra.com/files/assets/images/p-slide/couple%20journey.png" class="img-fluid couple" alt="Make Your journey Happier">
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </li>
                      <!-- for big menu  -->
            <!--========-->
            <li class="nav-item dropdown megamenu-li dmenu">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span onclick="location.href='https://templemitra.com/honeymoon-packages';"> Honeymoon Packages</span>
              </a>
              <div class="dropdown-menu megamenu sm-menu border-top" aria-labelledby="dropdown01">
                <div class="row m-0">
                  <div class="col-sm-9">
                    <div class="row m-0">
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/honeymoon-packages/andaman-honeymoon-packages"><i class="far fa-star m-icon"></i> Andaman Honeymoon Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/honeymoon-packages/central-india-honeymoon-packages"><i class="far fa-star m-icon"></i> Central India Honeymoon Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/honeymoon-packages/goa-honeymoon-packages"><i class="far fa-star m-icon"></i> Goa Honeymoon Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/honeymoon-packages/himachal-honeymoon-packages"><i class="far fa-star m-icon"></i> Himachal Honeymoon Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/honeymoon-packages/kashmir-honeymoon-packages"><i class="far fa-star m-icon"></i> Kashmir Honeymoon Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/honeymoon-packages/leh-ladakh-honeymoon-packages"><i class="far fa-star m-icon"></i> Leh Ladakh Honeymoon Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/honeymoon-packages/maharashtra-honeymoon-packages"><i class="far fa-star m-icon"></i> Maharashtra Honeymoon Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/honeymoon-packages/north-east-honeymoon-packages"><i class="far fa-star m-icon"></i> North East Honeymoon Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/honeymoon-packages/rajasthan-honeymoon-packages"><i class="far fa-star m-icon"></i> Rajasthan Honeymoon Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/honeymoon-packages/south-india-honeymoon-packages"><i class="far fa-star m-icon"></i> South India Honeymoon Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/honeymoon-packages/uttarakhand-honeymoon-packages"><i class="far fa-star m-icon"></i> Uttarakhand Honeymoon Packages</a>
                        </div>
                                          </div>
                  </div>
                  <div class="col-sm-3 hide">
                    <div class="topm_carousel">
                      <div id="carouselExampleControlsm" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                          <div class="carousel-item active ">
                            <img src="https://templemitra.com/files/assets/images/p-slide/chardham-yatra-package.png" class="img-fluid couple" alt="Make Your journey Happier">
                            <a class="text-light" target="_blank" href="http://chardhampackageonline.com/Char-Dham-Group-Departure-EX-Delhi.php">
                              <div class="carousel-caption bg-scroll">
                                     <h3>Chardham Group Departure EX-Delhi (2025) <br> INR: 22,500</h3>
                                <p>(02-May, 09-May, 16-May, 23-May, 30-May, 03-June & 07- June)</p>
                              </div>
                            </a>
                          </div>
                          <div class="carousel-item">
                            <img src="https://templemitra.com/files/assets/images/p-slide/chardham-yatra-package.png" class="img-fluid couple" alt="Make Your journey Happier">

                            <a class="text-light" href="http://chardhampackageonline.com/Char-Dham-Group-Departure-EX-Haridwar.php" target="_blank">
                              <div class="carousel-caption bg-scroll">
                                <h3>Chardham Group Departure EX-Haridwar (2025) <br> INR: 19,500</h3>
                                <p>(03-May, 10-May, 17-May, 24-May, 31-May, 04-June & 08- June)</p>
                              </div>
                            </a>
                          </div>
                          <div class="carousel-item">
                            <img src="https://templemitra.com/files/assets/images/p-slide/couple%20journey.png" class="img-fluid couple" alt="Make Your journey Happier">
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </li>
                      <!-- for big menu  -->
            <!--========-->
            <li class="nav-item dropdown megamenu-li dmenu">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span onclick="location.href='https://templemitra.com/holiday-packages';"> Holiday Packages</span>
              </a>
              <div class="dropdown-menu megamenu sm-menu border-top" aria-labelledby="dropdown01">
                <div class="row m-0">
                  <div class="col-sm-9">
                    <div class="row m-0">
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/holiday-packages/andaman-tour-packages"><i class="far fa-star m-icon"></i> Andaman Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/holiday-packages/goa-tour-packages"><i class="far fa-star m-icon"></i> Goa Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/holiday-packages/himachal-tour-packages"><i class="far fa-star m-icon"></i> Himachal Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/holiday-packages/kashmir-tour-packages"><i class="far fa-star m-icon"></i> Kashmir Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/holiday-packages/kerala-tour"><i class="far fa-star m-icon"></i> Kerala Tour</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/holiday-packages/leh-ladakh-tour-packages"><i class="far fa-star m-icon"></i> Leh Ladakh Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/holiday-packages/mysore-tour-packages"><i class="far fa-star m-icon"></i> Mysore Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/holiday-packages/north-east-tour-packages"><i class="far fa-star m-icon"></i> North East Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/holiday-packages/ooty-tour-packages"><i class="far fa-star m-icon"></i> Ooty Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/holiday-packages/rajasthan-tour-packages"><i class="far fa-star m-icon"></i> Rajasthan Tour Packages</a>
                        </div>
                      
                        <div class="col-sm-6 col-lg-4 border-right">
                          <a class="dropdown-item" href="https://templemitra.com/holiday-packages/uttarakhand-tour-packages"><i class="far fa-star m-icon"></i> Uttarakhand Tour Packages</a>
                        </div>
                                          </div>
                  </div>
                  <div class="col-sm-3 hide">
                    <div class="topm_carousel">
                      <div id="carouselExampleControlsm" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                          <div class="carousel-item active ">
                            <img src="https://templemitra.com/files/assets/images/p-slide/chardham-yatra-package.png" class="img-fluid couple" alt="Make Your journey Happier">
                            <a class="text-light" target="_blank" href="http://chardhampackageonline.com/Char-Dham-Group-Departure-EX-Delhi.php">
                              <div class="carousel-caption bg-scroll">
                                     <h3>Chardham Group Departure EX-Delhi (2025) <br> INR: 22,500</h3>
                                <p>(02-May, 09-May, 16-May, 23-May, 30-May, 03-June & 07- June)</p>
                              </div>
                            </a>
                          </div>
                          <div class="carousel-item">
                            <img src="https://templemitra.com/files/assets/images/p-slide/chardham-yatra-package.png" class="img-fluid couple" alt="Make Your journey Happier">

                            <a class="text-light" href="http://chardhampackageonline.com/Char-Dham-Group-Departure-EX-Haridwar.php" target="_blank">
                              <div class="carousel-caption bg-scroll">
                                <h3>Chardham Group Departure EX-Haridwar (2025) <br> INR: 19,500</h3>
                                <p>(03-May, 10-May, 17-May, 24-May, 31-May, 04-June & 08- June)</p>
                              </div>
                            </a>
                          </div>
                          <div class="carousel-item">
                            <img src="https://templemitra.com/files/assets/images/p-slide/couple%20journey.png" class="img-fluid couple" alt="Make Your journey Happier">
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </li>
          
          <!--for interational  -->
          
            <!--========-->
            <li class="nav-item dmenu dropdown">
              <a class="nav-link dropdown-toggle" href="https://templemitra.com/international-packages" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span onclick="location.href='https://templemitra.com/international-packages';"> International  Packages</span></a>
              <div class="dropdown-menu sm-menu" aria-labelledby="navbarDropdown">
                                  <a class="dropdown-item" href="https://templemitra.com/international-packages/bali-tour-packages"><i class="far fa-star m-icon"></i> Bali Tour Packages</a>
                                  <a class="dropdown-item" href="https://templemitra.com/international-packages/dubai-tour-package"><i class="far fa-star m-icon"></i> Dubai Tour Package</a>
                                  <a class="dropdown-item" href="https://templemitra.com/international-packages/kailash-mansarovar-yatra-packages"><i class="far fa-star m-icon"></i> Kailash Mansarovar Yatra Packages</a>
                                  <a class="dropdown-item" href="https://templemitra.com/international-packages/maldives-tour-package"><i class="far fa-star m-icon"></i> Maldives Tour Package</a>
                                  <a class="dropdown-item" href="https://templemitra.com/international-packages/thailand-tour-package"><i class="far fa-star m-icon"></i> Thailand Tour Package</a>
                              </div>
            </li>
                    <li class="nav-item dropdown megamenu-li dmenu">
            <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <span onclick="location.href='https://templemitra.com/destination';"> Destination</span>
            </a>
            <div class="dropdown-menu megamenu sm-menu border-top" aria-labelledby="dropdown01">
              <div class="row m-0">
                                  <div class="col-sm-2 col-lg-2  border-right mb-4">
                    <h5 class="font-weight-bold pl-4 my-tour-p1"> North India</h5>
                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/uttarakhand"><i class="far fa-star m-icon"></i>
                          Uttarakhand                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/shimla-manali"><i class="far fa-star m-icon"></i>
                          Shimla-Manali                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/kashmir-ladakh"><i class="far fa-star m-icon"></i>
                          Kashmir-Ladakh                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/delhi-agra-jaipur"><i class="far fa-star m-icon"></i>
                          Delhi-Agra-Jaipur                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/rajasthan"><i class="far fa-star m-icon"></i>
                          Rajasthan                        </a>
                      



                                      </div>
                                  <div class="col-sm-2 col-lg-2  border-right mb-4">
                    <h5 class="font-weight-bold pl-4 my-tour-p1"> North East</h5>
                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/darjeeling-gangtok"><i class="far fa-star m-icon"></i>
                          Darjeeling-Gangtok                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/meghalaya"><i class="far fa-star m-icon"></i>
                          Meghalaya                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/arunachal-pradesh"><i class="far fa-star m-icon"></i>
                          Arunachal Pradesh                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/assam"><i class="far fa-star m-icon"></i>
                          Assam                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/nagaland"><i class="far fa-star m-icon"></i>
                          Nagaland                        </a>
                      



                                      </div>
                                  <div class="col-sm-2 col-lg-2  border-right mb-4">
                    <h5 class="font-weight-bold pl-4 my-tour-p1"> East India</h5>
                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/odisha"><i class="far fa-star m-icon"></i>
                          Odisha                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/west-bengal"><i class="far fa-star m-icon"></i>
                          West-Bengal                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/bihar"><i class="far fa-star m-icon"></i>
                          Bihar                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/ayodhya-varanasi-prayagraj"><i class="far fa-star m-icon"></i>
                          Ayodhya-Varanasi-Prayagraj                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/jharkhand"><i class="far fa-star m-icon"></i>
                          Jharkhand                        </a>
                      



                                      </div>
                                  <div class="col-sm-2 col-lg-2  border-right mb-4">
                    <h5 class="font-weight-bold pl-4 my-tour-p1"> Central India</h5>
                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/chhattisgarh"><i class="far fa-star m-icon"></i>
                          Chhattisgarh                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/ujjain-indore"><i class="far fa-star m-icon"></i>
                          Ujjain-Indore                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/orchha-gwalior "><i class="far fa-star m-icon"></i>
                          Orchha-Gwalior                         </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/bhopal"><i class="far fa-star m-icon"></i>
                          Bhopal                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/khajuraho-jabalpur-panna"><i class="far fa-star m-icon"></i>
                          Khajuraho-Jabalpur-Panna                        </a>
                      



                                      </div>
                                  <div class="col-sm-2 col-lg-2  border-right mb-4">
                    <h5 class="font-weight-bold pl-4 my-tour-p1"> South India</h5>
                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/hyderabad"><i class="far fa-star m-icon"></i>
                          Hyderabad                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/karnataka"><i class="far fa-star m-icon"></i>
                          Karnataka                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/ooty"><i class="far fa-star m-icon"></i>
                          Ooty                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/andaman"><i class="far fa-star m-icon"></i>
                          Andaman                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/kerala"><i class="far fa-star m-icon"></i>
                          Kerala                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/uttarakhand"><i class="far fa-star m-icon"></i>
                          Uttarakhand                        </a>
                      



                                      </div>
                                  <div class="col-sm-2 col-lg-2  border-right mb-4">
                    <h5 class="font-weight-bold pl-4 my-tour-p1"> West India</h5>
                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/maharashtra"><i class="far fa-star m-icon"></i>
                          Maharashtra                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/gujarat"><i class="far fa-star m-icon"></i>
                          Gujarat                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/daman-diu"><i class="far fa-star m-icon"></i>
                          Daman-Diu                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/lakshadweep"><i class="far fa-star m-icon"></i>
                          Lakshadweep                        </a>
                      



                    

                        <a class="dropdown-item border-bottom" href=" https://templemitra.com/goa"><i class="far fa-star m-icon"></i>
                          Goa                        </a>
                      



                                      </div>
                
              </div>
            </div>
          </li>
          <li class="nav-item dropdown megamenu-li dmenu">
            <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <span onclick="location.href='https://templemitra.com/tour-vision';"> Tour Vision</a>


            <div class="dropdown-menu megamenu sm-menu border-top" aria-labelledby="dropdown01">
              <div class="row m-0">

                                  <div class="col-sm-3 col-lg-3  border-right mb-4">
                    <h5 class="font-weight-bold pl-4 my-tour-p1"> Places By Month</h5>

                    <div class="row m-0">
                      
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/january"><i class="far fa-star m-icon"></i>
                              January                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/february"><i class="far fa-star m-icon"></i>
                              February                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/march"><i class="far fa-star m-icon"></i>
                              March                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/april"><i class="far fa-star m-icon"></i>
                              April                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/may"><i class="far fa-star m-icon"></i>
                              May                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/june"><i class="far fa-star m-icon"></i>
                              June                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/july"><i class="far fa-star m-icon"></i>
                              July                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/august"><i class="far fa-star m-icon"></i>
                              August                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/september"><i class="far fa-star m-icon"></i>
                              September                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/october"><i class="far fa-star m-icon"></i>
                              October                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/november"><i class="far fa-star m-icon"></i>
                              November                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/december"><i class="far fa-star m-icon"></i>
                              December                            </a>
                          </div>
                                                                  </div>
                  </div>

                                  <div class="col-sm-3 col-lg-3  border-right mb-4">
                    <h5 class="font-weight-bold pl-4 my-tour-p1"> Experiences</h5>

                    <div class="row m-0">
                      
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/bike-tours"><i class="far fa-star m-icon"></i>
                               Bike Tours                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/luxury-holidays"><i class="far fa-star m-icon"></i>
                               Luxury Holidays                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/honeymoon"><i class="far fa-star m-icon"></i>
                               Honeymoon                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/beaches"><i class="far fa-star m-icon"></i>
                               Beaches                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/backwaters"><i class="far fa-star m-icon"></i>
                               Backwaters                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/adventure"><i class="far fa-star m-icon"></i>
                               Adventure                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/ashrams"><i class="far fa-star m-icon"></i>
                               Ashrams                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/ayurveda"><i class="far fa-star m-icon"></i>
                               Ayurveda                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/religious-places"><i class="far fa-star m-icon"></i>
                               Religious Places                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/wildlife"><i class="far fa-star m-icon"></i>
                               Wildlife                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/forts-palaces"><i class="far fa-star m-icon"></i>
                               Forts & Palaces                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/culture"><i class="far fa-star m-icon"></i>
                               Culture                            </a>
                          </div>
                                                                  </div>
                  </div>

                                  <div class="col-sm-3 col-lg-3  border-right mb-4">
                    <h5 class="font-weight-bold pl-4 my-tour-p1"> Duration</h5>

                    <div class="row m-0">
                      
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/1-to-4-days"><i class="far fa-star m-icon"></i>
                              1 To 4 Days                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/4-to-8-days"><i class="far fa-star m-icon"></i>
                               4 To 8 Days                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/8-to-12-days"><i class="far fa-star m-icon"></i>
                               8 To 12 Days                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/12-to-16-days"><i class="far fa-star m-icon"></i>
                               12 To 16 Days                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/16-to-20-days"><i class="far fa-star m-icon"></i>
                               16 To 20 Days                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/20-days"><i class="far fa-star m-icon"></i>
                               20+ Days                            </a>
                          </div>
                                                                  </div>
                  </div>

                                  <div class="col-sm-3 col-lg-3  border-right mb-4">
                    <h5 class="font-weight-bold pl-4 my-tour-p1"> A To Z Places</h5>

                    <div class="row m-0">
                      
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/a-to-d-days"><i class="far fa-star m-icon"></i>
                              A To D Days                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/e-to-i-places"><i class="far fa-star m-icon"></i>
                               E To I Places                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/j-to-m-places"><i class="far fa-star m-icon"></i>
                               J To M Places                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/n-to-q-places"><i class="far fa-star m-icon"></i>
                               N To Q Places                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/r-to-u-places"><i class="far fa-star m-icon"></i>
                               R To U Places                            </a>
                          </div>
                                              
                          <div class="col-xl-6 col-md-6 col-6">
                            <a class="dropdown-item border-bottom" href=" https://templemitra.com/v-to-z-places"><i class="far fa-star m-icon"></i>
                               V To Z Places                            </a>
                          </div>
                                                                  </div>
                  </div>

                              </div>
            </div>

          </li>
          <li class="nav-item dmenu dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <span> MORE</span>
            </a>
            <div class="dropdown-menu sm-menu" aria-labelledby="navbarDropdown">
              <!-- <a class="dropdown-item" href="#">Weekend Gateways </a> -->
              <!-- <a class="dropdown-item" href="#">Fixed Departures ( Group Tours )</a> -->
              <a class="dropdown-item" href="https://templemitra.com/packages-by-theme">Packages by Theme</a>
              <!-- <a class="dropdown-item" href="https://templemitra.com/special-occasions">Special Occasions</a> -->
              <!-- <a class="dropdown-item" href="#">Packages for Special Occasions </a> -->
              <a class="dropdown-item" href="https://templemitra.com/blogs.php">Travel Blog</a>
                <a class="dropdown-item" href="https://templemitra.com/group-packages.php">Group Packages</a>
            </div>
          </li>
          <!--=========-->
          <li class="nav-item dmenu dropdown">
            
              <span class="md-trigger signIn signIn-btn btn btn-sm btn-info" data-modal="modal-6"><i class="fas fa-sign-in-alt"></i> Login</span>

                      </li>
        </ul>
      </div>
    </div>
  </nav>
  <marquee class="scroll-marq">Bookings have been started for CHARDHAM YATRA 2025. Exclusive Chardham Budget, Deluxe, Luxury , Helicopter & Group Packages are available. For Booking & Special Rates , Contact on +91-7678398674, +91-8851694514.</marquee>
</div>

<!--  pay online  -->
<div class="modal fade" id="PayModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header bg-primary text-light text-center">
                <h2 class="w-100 text-center">Online Payment</h2>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <form id="paymentForm" action="/templemitra-pay/payment-checkout.php" method="post" onsubmit="return validateForm()">

                    <!-- Name -->
                    <div class="input-group mb-2">
                        <div class="input-group-prepend group-pay">
                            <span class="input-group-text ico-bg"> <i class="icofont icofont-user-male"></i> </span>
                        </div>
                        <input autocomplete="off" type="text" class="form-control" name="cust_name" id="cust_name" placeholder="Enter Your Full Name*" required>
                    </div>

                    <!-- Mobile number -->
                    <div class="input-group mb-2">
                        <div class="input-group-prepend group-pay">
                            <span class="input-group-text ico-bg"> <i class="icofont icofont-iphone"></i> </span>
                        </div>
                        <input autocomplete="off" class="form-control" type="text" name="cust_numb" id="cust_numb" pattern="[0-9]{10}" title="Please Enter Your 10 Digit Mobile Number" placeholder="Enter Your Mobile Number*" required>
                    </div>

                    <!-- Email -->
                    <div class="input-group mb-2">
                        <div class="input-group-prepend group-pay">
                            <span class="input-group-text ico-bg"> <i class="icofont icofont-email"></i> </span>
                        </div>
                        <input autocomplete="off" class="form-control" type="email" name="cust_email" id="cust_email" placeholder="Enter Your Email id*" required>
                    </div>

                    <!-- Package Name -->
                    <div class="input-group mb-2">
                        <div class="input-group-prepend group-pay">
                            <span class="input-group-text ico-bg"> <i class="icofont icofont-location-pin"></i> </span>
                        </div>
                        <input autocomplete="off" type="text" class="form-control" name="package_group_name" id="package_group_name" placeholder="Enter Your Package Name*" required>
                    </div>

                    <!-- Amount -->
                    <div class="input-group mb-2">
                        <div class="input-group-prepend group-pay">
                            <span class="input-group-text ico-bg"> <i class="fas fa-rupee-sign"></i> </span>
                        </div>
                        <input autocomplete="off" id="box1" oninput="calculate();" class="form-control" type="text" name="partial_amount" id="partial_amount" placeholder="Payable Amount*" required>
                    </div>

                    <!-- Reminder Amount -->
                    <div class="input-group mb-2">
                        <div class="input-group-prepend group-pay">
                            <span class="input-group-text ico-bg">Rupya!</span>
                        </div>
                        <input autocomplete="off" class="form-control" id="words" readonly>
                    </div>

                    <!-- Submit -->
                   <input name="submit" type="submit" value="Pay Now" id="submitBtn" class="form-control bg-success text-light">


                </form>
            </div>
        </div>

    </div>
</div>


<div class="top"></div>

<!--  pay online  -->

<script>
    // Ensure the script runs after the DOM is fully loaded
    document.addEventListener("DOMContentLoaded", function() {
        // Validate the form before submission
        function validateForm() {
            // Validate Name (must contain only letters and spaces)
            var name = document.getElementById('cust_name');
            if (name && !/^[a-zA-Z\s]+$/.test(name.value)) {
                alert('Name must contain only letters and spaces.');
                return false; // Prevent form submission
            }

            // Validate Mobile Number (must be exactly 10 digits)
            var mobileNumber = document.getElementById('cust_numb');
            if (mobileNumber && !/^\d{10,12}$/.test(mobileNumber.value)) {
                alert('Please enter a valid mobile number.');
                return false; // Prevent form submission
            }

            // Validate Email
            var email = document.getElementById('cust_email');
            var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (email && !emailPattern.test(email.value)) {
                alert('Please enter a valid email address.');
                return false; // Prevent form submission
            }

            // Validate Package Name
            var packageName = document.getElementById('package_group_name');
            if (packageName && !/^[a-zA-Z\s]+$/.test(packageName.value)) {
                alert('Package name must contain only letters and spaces.');
                return false; // Prevent form submission
            }

            // Validate Partial Amount (must be a positive number)
            var amount = document.getElementById('partial_amount');
            if (amount && (isNaN(amount.value) || amount.value <= 0 || amount.value.length < 1 || amount.value.length > 10)) {
                alert('Please enter a valid payable amount.');
                return false; // Prevent form submission
            }

            // Disable the "Pay Now" button to prevent multiple submissions
            var submitButton = document.getElementById('submitBtn');
            if (submitButton) {
                submitButton.disabled = true;  // Disable the button
                submitButton.value = "Please wait..."; // Optionally change the button text
                submitButton.style.backgroundColor = "#999";  // Optionally change the button color to indicate it's disabled
                submitButton.style.display = "none";  // Hide the button
            }

            // Submit the form after all validations pass
            return true; 
        }

        // Attach the validateForm function to the form's onsubmit event
        document.getElementById('paymentForm').onsubmit = validateForm;
    });
</script>




    
<script>
  //  Search  
  $(document).on('focus', '#search', function() {
    $("#livesearch").show();
    $(".navbar-collapse").removeClass('show');
    $(".cross").show();
  });
  $(document).on('blur', '#search', function() {
    $("#livesearch").fadeOut();
    $(".cross").fadeOut();
    $(".serc-alt").fadeOut();
  });
  $(document).on('click', '.bootstrap-touch-slider,.slide-text,.bs-slider-overlay,.bs-slider-overlay', function() {
    $("#search").blur();
    $("#livesearch").fadeOut();
    $(".serc-alt").fadeOut();
    $(".cross").fadeOut();
  });
  $(document).on('click', '.cross', function() {
    $("#search").val('');
    $("#search").blur();
    $("#livesearch").fadeOut();
    $(".cross").fadeOut();
    $(".serc-alt").fadeOut();
  });


  $(document).on('keyup', '#search', function() {
    $("#livesearch").show();
    $(".serc-alt").show();
    $(".cross").show();

    var key = $("#search").val();
    // when input empty 

    if (key.length == 0) {
      $("#livesearch").fadeOut();
      $(".serc-alt").fadeOut();
    }

    if (key.length >= 1) {
      $.ajax({
        url: "https://templemitra.com/search-call.php",
        method: "POST",
        data: {
          key: key
        },
        success: function(data) {
          $(".serc-alt").fadeOut();
          $("#livesearch").html(data);
        }
      })
    } else {
      $("#livesearch").fadeOut();
    }
  });



  var header = document.getElementById("myHeader");
  var sticky = header.offsetTop;

  if (window.matchMedia("(max-width: 768px)").matches) {
    $(".top").removeClass("top")
    window.onscroll = function() {
      mScroll()
    };

    function mScroll() {
      if (window.pageYOffset > sticky) {
        header.classList.add("sticky");
        $(".hidden-xs").addClass("sticky-search")
        $(".card-w").addClass("m-card")
        $(".form-search").addClass("m-search")
      } else {
        header.classList.remove("sticky");
        $(".hidden-xs").removeClass("sticky-search")
        $(".card-w").removeClass("m-card")
        $(".form-search").removeClass("m-search")
      }
    }
  }
  if (!window.matchMedia("(max-width: 768px)").matches) {
    $(".nav-radius").addClass("fixed-top")
    // for menu hover 
    $('.navbar-light .dmenu').hover(function() {
      $(this).find('.sm-menu').first().stop(true, true).slideDown(10);
    }, function() {
      $(this).find('.sm-menu').first().stop(true, true).slideUp(100)
    });

    $(".megamenu").on("click", function(e) {
      e.stopPropagation();
    });

  }

  // Amount to text 
  var a = ['', 'one ', 'two ', 'three ', 'four ', 'five ', 'six ', 'seven ', 'eight ', 'nine ', 'ten ', 'eleven ', 'twelve ', 'thirteen ', 'fourteen ', 'fifteen ', 'sixteen ', 'seventeen ', 'eighteen ', 'nineteen '];
  var b = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];

  function inWords(num) {
    if ((num = num.toString()).length > 9) return 'overflow';
    n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
    if (!n) return;
    var str = '';
    str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'crore ' : '';
    str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'lakh ' : '';
    str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'thousand ' : '';
    str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred ' : '';
    str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + 'only ' : '';
    return str;
  }

  document.getElementById('box1').onkeyup = function() {
    document.getElementById('words').value = inWords(document.getElementById('box1').value);
  };
</script>     <!-- body-->
     <!-- Page body start -->
     <div class="body-top">
          <div class="banner-image">
               <img class="banner-img" src="https://templemitra.com/files/assets/images/product/pricacy.jpg">
               <div class="packages-eq-top container-fluid">
                    <div class="row">
                         <div class="col-sm-8 p-0">
                              <h4 class="heading-custom">Privacy Policy</h4>
                         </div>
                         <div class="col-sm-4 p-0">
                              <div class="md-content m-4">
                                   <h3 class="text-center">Contact us Form</h3> 
                                   <div class="j-pro" id="j-pro" novalidate="">
                                        <div class="j-content">
                                             <!-- start name -->
                                             <div class="j-row">
                                                  <div class="j-span6 j-unit">
                                                  <div class="j-input">
                                                       <label class="j-icon-right" for="name">
                                                            <i class="icofont icofont-ui-user"></i>
                                                       </label>
                                                       <input type="text" id="name-t" placeholder="Enter Name*">
                                                       <span class="j-tooltip j-tooltip-right-top">Enter Name</span>
                                                  </div>
                                             </div>
                                             
                                             <div class="j-span6 j-unit">
                                                       <div class="j-input">
                                                            <label class="j-icon-right" for="phone">
                                                                 <i class="icofont icofont-phone"></i>
                                                            </label>
                                                            <input type="text" id="phone-t" placeholder="Enter Mobile. No*">
                                                            <span class="j-tooltip j-tooltip-right-top">
                                                                 Enter Mobile. No*
                                                            </span>
                                                       </div>
                                                  </div>
                                                  </div>
                                             <!-- end name -->
                                             <!-- start email phone -->
                                             <div class="j-row">
                                                  <div class="j-span12 j-unit">
                                                       <div class="j-input">
                                                            <label class="j-icon-right" for="email">
                                                                 <i class="icofont icofont-envelope"></i>
                                                            </label>
                                                            <input type="email" id="email-t" placeholder="Enter Email Id*">
                                                            <span class="j-tooltip j-tooltip-right-top">Enter Email Id</span>
                                                       </div>
                                                  </div>
                                             </div>
                                             <!-- end email phone -->
                                             <div class="j-divider j-gap-bottom-25"></div>
                                             <!-- start guests -->
                                             <input type="hidden" id="adults-t">
                                             <input type="hidden" id="children-t">
                                             <!-- end guests -->
                                             <!-- start message -->
                                             <div class="j-unit">
                                                  <label class="j-label">Additional Information ( Optional )
                                                  </label>
                                                  <div class="j-input">
                                                       <textarea id="message-t" spellcheck="false" cols="5" placeholder="message"></textarea>
                                                  </div>
                                             </div>
                                             <!-- end message -->
                                             <!-- start response from server -->
                                             <div class="j-response"></div>
                                             <!-- end response from server -->
                                        </div>
                                        <input class="form-control" type="hidden" id="my-package" value="enquiry from contact us Page" />
                                        <!-- end /.content -->
                                        <div class="j-footer">
                                             <button type="submit" class="btn btn-primary send-enq-t">Booking</button>
                                        </div>
                                        <div class="text-center p-2" id="alt-t"></div>
                                   </div>
                              </div>
                         </div>
                    </div>
               </div>
          </div>
          <div class="container m_content">
                
<h2>Privacy Policy </h2>

<p>Templemitra is a registered trademark of AVICHAL SRISHTISUTRA INFOTAINMENT PRIVATE LIMITED having its registered office at 
C4, Rayos Building, Sector 63 Rd, C Block, Sector 63, Noida, Uttar Pradesh 201301. 

We maintain a high degree of privacy of the personal details of our customers. </p>

<p>We attempt to support the right not to be public of the personal knowledge on condition that by you. however, 
it would be necessary for us to part this knowledge with taxi service providers, air-transport businesses, hotels and other supporting service providers 
during or before the journey to provide necessary support to your tour programme.</p>

<p>We would also be limited to give news such news given if we get an order of the Court , a requisition from any government or rule-given authority, 
, or where under any laws, rules or rules, such becomes necessary. </p>

<p>Templemitra.com will not sell, trade or disclose to third parties any information derived from the registration for, 
or use of, any online service (including names and addresses) without the consent of the user 
or customer (except as required by subpoena, search warrant, or other legal process or in the case of imminent physical harm to the user or others).</p>
<p>Templemitra allow suppliers to access the information for purposes of confirming your registration and providing you with benefits you are entitled to.</p>

<p>We have enabled all security parameters into our website www.Templemitra.com like SSL certificates to protect your personal information.</p>
We are taking help of registered and secured payment gateway service providers.</p>

<p>You be in agreement to let us camera picture and / or videograph the journey and specially you be in agreement to let us camera picture and / or videograph 
you in the direction of the journey. You be in agreement to let us put into print such camera pictures
 / videographs through all thing by which something is done including print thing by which something is done, places in the net, letters, emails and so on. </p>
<p>You also be in agreement to let us unbroken bands over wheels for moving over rough earth use statistics.</p>

<p>To protect the individual information of our clients, we may make changes in our privacy policies as per law as and when needed. Any such change info with 
efffective date will be shown here on the privacy page of the website. </p>

<p>Thanks for visiting and using our website https://templemitra.com/</p>

          </div>
 
     </div>
     <!-- Row end -->

   
  <style>
        
    /* Default styles for the button 
#Guests  {
   margin-right:487px;
    margin-left:457px;
    margin-top:26px;
    border-radius:10px;
    font-size:25px;
    background-color:#ffc107;
    margin-bottom:-12px;
}
*/
/* Media query for smaller screens */
@media only screen and (max-width: 600px) {
    .gues {
        margin-right: 35px; /* Adjust margin-right for smaller screens */
        margin-left: 35px;
        font-size:xx-large;
             padding-left:36px;/* Adjust margin-left for smaller screens */
    }
}

.touch {
    margin-right: 21px; /* Adjust margin-right for larger screens */
    margin-left: auto; /* Align to the right */
    margin-top: 26px;
    border-radius: 10px;
    font-size: 25px;
    background-color: #ffc107;
    margin-bottom: -12px;
    cursor: pointer;
    transition: transform 0.2s;
    display: inline-block; /* Ensure the text doesn't take full width */
}

/* Media query for smaller screens */
@media only screen and (max-width: 600px) {
    .touch {
        margin-right: 21px; /* Adjust margin-right for smaller screens */
        margin-left: auto; /* Align to the right */
        font-size: xx-large;
        padding-left: 36px;
        margin-top: 26px; /* Adjust margin-top for smaller screens */
    }
}

.touch:hover {
    transform: translateX(5px);
}

    
    
    
    .temp{
        font-size:medium;
          margin-top:9px;
          color:white;
    }
    
    .tempimg{
     
      width:200px;
    
    }
   
.ban-short-links{
     MARGIN-TOP: 12PX;
    background-color: #ffffff;
    margin-left: -16px;
    margin-right: 185px;
    border-radius:10px;
     width: 100%;
    text-align: center;
    
}
* {
  box-sizing: border-box;
}


.service:hover {
  -ms-transform: scale(1.5); /* IE 9 */
  -webkit-transform: scale(1.5); /* Safari 3-8 */
  transform: scale(1.5); 
   background-color: green;
}

.service {
     transition: transform .2s;
    border: 1px solid #ccc;
    padding: 10px;
    display: inline-block; /* This ensures each service is displayed in a line */
  margin: 0 10px 10px 0; 
    background-color:#6c757d;/* Adjust margin as needed */
     box-sizing: border-box;
     margin-top:10px;
     border-radius:10px;
     width:180px;
      
}

.service img {
    max-width: 100%; /* Ensure images don't exceed container width */
    height: auto; /* Maintain aspect ratio */
}

.service h4 {
    margin: 10px 0 5px; /* Add margin top and bottom */
}


@media only screen and (max-width: 600px) {
    .service {
        width: calc(50% - 20px); /* Adjust width to fit two services per row */
        margin-right: 10px; /* Add margin to create space between services */
        margin-bottom: 10px; /* Add margin to create space between rows */
    }
}

    
        .split {
            height: 100%;
            width: 50%;
            position: fixed;
            z-index: 1;
            top: 0;
            overflow-x: hidden;
            padding-top: 20px;
            display: none;
        }

        .show-contact-form .split.right {
            display: block;
        }

        .right {
            right: -202px;
            position: absolute;
            margin-top: 127px;
            margin-right: -109px;
        }

        /* New CSS for mobile */
        @media (max-width: 768px) {
            .split {
                width: 100%;
                height: 50%;
                top: unset;
                bottom: -100%;
                padding-top: 0;
                padding-bottom: 20px;
            }

            .show-contact-form .split.right {
                bottom: 0;
            }

            .right {
                right: 0;
                margin-top: unset;
                margin-right: unset;
            }
        }


        .pagination-container {

            justify-content: space-between;
            margin-left: 459px;
            margin-top: 10px;
            /* Adjust this value as needed */
        }

        .prev-btn,
        .next-btn {
            border-radius: 11px;
            background-color: #ffc107;
            padding: 5px 10px;
            /* Add padding to buttons for better spacing */
        }

        /* Media query for mobile devices */
        @media (max-width: 768px) {
            .pagination-container {
                justify-content: center;
                margin-left: 0;
                display: flex;


            }
        }

        h3.one {
            border-style: solid;
            border-width: 2px;
            margin-right: 461px;
            padding-left: 33px;
            font-size: x-large;
            border-radius: 26px;
            background-color: paleturquoise;
        }

        @media (max-width: 767px) {
            h3.one {
             
                /* Remove the right margin */
                margin-bottom: 15px;
               
               
                 margin-right: 0 !important;
                margin-left: 0 !important;
                /* Add some bottom margin for spacing */
            }
        }
        
            @media (max-width: 767px) {
           p.three {
                 margin-right: 0 !important;
            margin-left: 0 !important;
            }
        }

        .horizontal-align {
            display: inline-block;
            white-space: nowrap;
            margin-left: -53px;
            margin-top: 6px;
        }
        
        .two {
        margin-top: 39px;
        margin-left: 21px;
        display: flex;
        align-items: center;
        border-style: solid;
        border-width: 2px;
        margin-right: 15px; /* Adjusted margin-right for mobile */
        padding-left: 33px;
        font-size: large; /* Adjusted font size for mobile */
        border-radius: 26px;
        background-color: paleturquoise;
    }

      @media (max-width: 768px) {
        .two {
            margin-right: 0 !important;
            margin-left: 0 !important;
        }
    }
    
    .modal-title {
    font-size: large;
    
    border-radius: 4px;
}

#saveReview:hover {
    background-color: red !important; /* Change the color to your desired hover color */
}


/* by anurag why templemitra.com in index page */

    
        .cus {
            color: white;
        }

        .carousel-horizontal .carousel-inner .item {
            flex: 0 0 auto;
            width: 100%;
        }

        .carousel-horizontal .carousel-inner .item img {
            max-width: 100%;
            height: auto;

        }

        .carousel {
            display: flex;
            overflow: hidden;
        }

        .carousel .carousel-inner {
            display: flex;
            transition: transform 0.5s ease;
        }

        .carousel .item {
            flex: 0 0 auto;
            width: 100%;
        }

        .carousel-container {
            position: relative;
            overflow: hidden;

        }

        .carousel-inner {
            display: flex;
            transition: transform 0.5s ease;
        }

        .item {
            flex: 0 0 100%;
        }

        .carousel-control {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(0, 0, 0, 0.5);
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
        }

        .carousel-control.prev {
            left: 0;
        }

        .carousel-control.next {
            right: 0;
        }

        .why-newbox {
            display: flex;
            flex-wrap: wrap;
            margin-left: -143px;
            background-color: white;
            border-radius: 5px;

        }

        .why-newbox li {
            width: calc(33.33% - 20px);
            /* 33.33% for three items per row and subtracting margin */
            margin-bottom: 20px;
            text-align: center;

            border: 2px solid #343a40;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.5);
            list-style-type: none;
            height: 150px;
            border-radius: 10px;
            /* Adding a border for better visibility */
        }

        @media (max-width: 768px) {
            .why-newbox {
            display: flex;
            flex-wrap: wrap;
            margin-left: 0; /* Remove the negative margin */
            padding: 0 10px; /* Add padding to the container for spacing */
            }
            
            .why-newbox li {
            width: calc(50% - 20px); /* Adjusted width to consider margins */
            margin: 10px; /* Add margin on all sides of each item */
            box-sizing: border-box; /* Include padding and border in the width calculation */
            }
            }
    
    /* by anurag why abous us payment  */
            .button-container {
            border: 1px solid black;
            border-radius: 15px;
            display: flex;
            padding: 10px;
            width: fit-content;
            cursor: pointer;
        }

        .text-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-left: 10px;
            justify-content: center;
            margin-right: 10px;
        }

        .logo-container {
            width: 40px;
            height: 40px;
        }

        .seconday-logo-container {
            width: 16px;
            height: 16px;
            vertical-align: middle;
        }

        a {
            text-decoration: none;
        }
        
   .ban {
    margin-top: -35px;
    color: white;
    font-size: 40px;
    border-radius: 30px;
    border: 2px solid;
    margin-right: auto;
    margin-left: auto;
    max-width: 20%; 
    background-color: black;/* Set a maximum width to ensure responsiveness */
}

/* Media query for mobile devices */
@media (max-width: 768px) {
    .ban {
        font-size: 28px; 
         max-width: 50%;/* Adjust font size for smaller screens */
    }
}

.ban1{
   margin-top:8px;
   margin-left:73px;
}
@media (max-width: 768px) {
    .ban1 {
       margin-top: -13px;
       margin-left:-3px;
    /* Adjust font size for smaller screens */
    }
}

@media (max-width: 768px) {
    .details-container {
       margin-left:-42px;
        /* Adjust font size for smaller screens */
    }
}

@media (max-width: 768px) {
    .btn3 {
       margin-left:-42px;
        /* Adjust font size for smaller screens */
    }
}




/*  group packages css by anurag start */

 
        .package-info {
            padding: 15px;
        }

        .chardham-group-heading {
            margin-top:60px;
            color: black;
            font-size: 30px;
            border-radius: 30px;
            /*border: 2px solid;*/
            margin-right: auto;
            margin-left: auto;
            max-width: 100%;
            /*background-color: black;*/
            text-align: center;
        }

        .date-container {
            position: relative;
            display: inline-block;
            margin: 10px;
            cursor: pointer;
        }

        .avroom {
            background-color: green;
            color: yellow;
            border-radius: 2px;
            padding: 2px 4px;
        }

        .avroom:hover {
            text-decoration: underline;
            color: black;
        }

        .control-buttons {
            justify-content: space-between;
            align-items: center;

        }

        .control-buttons button {
            font-size: 16px;
            margin: -7px 8px;
        }

        .package-info table {
            width: 100%;
            border-collapse: collapse;
        }

        .package-info th,
        .package-info td {
            padding: 8px;
            border: 1px solid #ddd;
            background-color: #343a40;
            color: white;
            text-align: center;

        }

        @media (max-width: 480px) {

            .package-info th,
            .package-info td {
                padding: 8px;
                border: 1px solid #ddd;
                background-color: #343a40;
                color: white;
                text-align: center;
                width: 27%;
            }
        }


        .package-info th {
            background-color: black;
            color: white;
        }

        .package-info tr:nth-child(even) {
            background-color: #333;
        }

        .package-info tr:hover {
            background-color: white;
        }

        .group-date {
            border-radius: 4px;
            display: flex;
            justify-content: space-between;
            text-align: center;
            flex-wrap: wrap;
            background-color: black;
            color: white;
            margin: 25px 6px;
        }
        
            .group-date-amrnath {
            border-radius: 4px;
            display: flex;
            /*justify-content: space-between;*/
            text-align: center;
            flex-wrap: wrap;
            background-color: black;
            color: white;
            margin: 25px 6px;
        }


        /* New Button Styles */
        .button-pay-summary {
            text-align: right;
            margin-top: 20px;
            /*display: flex;*/
            justify-content: space-around;
        }

        .button-pay-summary button {
            padding: 4px 8px;
            background-color: green;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-left: 10px;
            margin: 2px;

            /* Add space between buttons */
        }

        .button-pay-summary button:hover {
            background-color: #45a049;
        }

        .contact-info-summary {
            float: left;
            color: #d9dbe4;
            background-color: #000000;
            padding: 4px 8px;
            border-radius: 4px;
        }



        /* Modal Styling */
        .modal-group {
            display: none;
            /* Hide modal initially */
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            /* Semi-transparent background */
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .modal-content-group {
            background-color: green;
            padding: 10px;
            border-radius: 8px;
            width: 90%;
            max-width: 800px;
            border: 1px solid;
            box-shadow: 1px 1px 1px #bf1212;
            position: relative;
            overflow: hidden;
        }

        /* Header section */
        .modal-header-group {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .modal-header-group h4 {
            margin: 0;
            color: white;
            font-size: 24px;
            margin-left: 18rem;
        }



        @media screen and (max-width: 600px) {
            .modal-header-group h4 {
                margin: 0;
                color: white;
                font-size: 24px;
                margin-left: 9rem;

            }
        }

        .close-btn {
            background-color: #ff4d4d;
            color: white;
            border: none;
            padding: 4px 8px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
        }

        .close-btn:hover {
            background-color: #ff1a1a;
        }

        /* Table Styling */
        .booking-table {
            width: 100%;
            border-collapse: collapse;
        }

        .booking-table th,
        .booking-table td {
            /*padding: 10px;*/
            border: 1px solid black;
            background-color: #f4f4f4;
            text-align: center;

        }

        .booking-table th {
            background-color: black;
            color: white;
        }

        .booking-table tr:nth-child(even) {
            background-color: #e9ecef;
        }

        .booking-table tr:hover {
            background-color: #ddd;
        }


        /* Footer and Button Styling */
        .button-pay-summary {
            text-align: right;
            margin-top: 20px;
        }

        .pay-btn {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
        }

        .pay-btn:hover {
            background-color: #218838;
        }

        /* Responsiveness */
        @media screen and (max-width: 600px) {
            .modal-content-group {
                width: 95%;
                padding: 15px;
            }

            .booking-table th,
            .booking-table td {
                font-size: 14px;
            }

            .close-btn,
            .pay-btn {
                padding: 6px 12px;
                font-size: 14px;
            }
        }
  
  .ico-bg-group {
background-color: #0c63af;
color: #fff;
width: 40px;
padding-left: 13px;

}

.bg-primary-group{
    background-color:green;
    color: white
}



.modal-content-pay {
    position: relative;
    display: -ms-flexbox;
    display: flex
;
    -ms-flex-direction: column;
    flex-direction: column;
    width: 100%;
    pointer-events: auto;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid rgba(0, 0, 0, .2);
    border-radius: .3rem;
    outline: 0;
    margin-top:7rem;
}

.selected-date {
    color: red;
    font-weight: bold;
}


* {
  box-sizing: border-box;
}

/* Create three equal columns that floats next to each other */
.column-notes-group {
 float: left;
    /* width: 33.33%; */
    /* padding: 42px; */
    color: white;
    margin: 14px 42px;
}

.row-notes-group{
    border-radius:5px;
    margin-top:0rem;
    background-color: blue;
    box-shadow: 1px 1px 1px #bf1212;
}

/* Clear floats after the columns */
.row-notes-group:after {
  content: "";
  display: table;
  clear: both;
}

.dep-heading{
    margin-top:15px;
    text-align: left;
}


   @media only screen and (max-width: 768px) {
        .column-notes-group {
            width: 100%;
            /* Make the columns stack vertically on smaller screens */
            padding: 4px;
            font-size: 16px;
            margin: 0px 0px;
            /* Optional: adjust padding for mobile */
            text-align: center;
            /* Center the text on mobile */
        }

        .row-notes-group {
            margin-top: 0;
            /* Optional: Adjust margin for mobile */
        }
    }
    
       @media only screen and (max-width: 480px) {
        .column-notes-group {
            padding: 3px;
            font-size: 16px;
            margin: 0px 0px;
            /* Adjust padding further for small screens */
        }
    }

.pdate{
    color:red;
    /*margin-top:-1rem;*/
}



/*  group packages css by anurag end */


   /*youtube video css start */

   /* Container for the slider */
        .youtube-slider-container {
            position: relative;
            width: 100%;
            max-width: 800px;
            margin: auto;
        }

        /* Hide all videos by default */
        .youtube-video-slide {
            display: none;
        }

        /* Style for the buttons (next and previous) */
        .youtube-prev, .youtube-next {
            position: absolute;
            top: 50%;
            padding: 16px;
            font-size: 18px;
            color: white;
            background-color: rgba(0, 0, 0, 0.5);
            border: none;
            cursor: pointer;
            border-radius: 50%;
        }

        .youtube-prev {
            left: 10px;
            transform: translateY(-50%);
        }

        .youtube-next {
            right: 10px;
            transform: translateY(-50%);
        }

        /* Hover effect for the buttons */
        .youtube-prev:hover, .youtube-next:hover {
            background-color: rgba(0, 0, 0, 0.8);
        }


   /*youtube video css end */

    </style>

 <div class="ban-short-links" style="background-color:#ffffff;">
    <ul >
        <div class="service">
            <img src="/files/assets/images/service.jpg" style="margin-top:4px;" alt="" class="tempimg">
            <h4 class="temp">BEST SERVICE</h4>
            <a href="" class="fclick"></a>
        </div>
        <div class="service">
            <img src="/files/assets/images/emi.png" alt="" class="tempimg">
            <h4 class="temp">EMI AVAILABLE</h4>
            <a href="" class="fclick"></a>
        </div>
        <div class="service">
            <img src="/files/assets/images/24.png" alt="" class="tempimg">
            <h4 class="temp">24*7 SUPPORT</h4>
            <a href="" class="fclick"></a>
        </div>
        <div class="service">
            <img src="/files/assets/images/guar.jpg" alt="" class="tempimg" style="margin-top:10px;">
            <h4 class="temp">BEST RATE GUARANTEED</h4>
            <a href="" class="fclick"></a>
        </div>
        <div class="buttons">
            
             <a href="#" class="btn-wrapper">
               <button type="button" class="btn btn-primary" onclick="showModal('modal-10')" style="
                        margin-bottom: 10px;
                        border-radius: 16px;
                        font-size:20px;
                    ">Get a Free Quote..</button>
            </a>
            
            
            
            
           <a href="https://templemitra.com/share-experience.php" class="btn-wrapper" target="_blank">
    <button type="button" class="btn btn-primary" style="
        margin-bottom: 10px;
        border-radius: 16px;
        font-size:20px;
    ">Guest Reviews</button>
</a>

        </div>
    </ul>
</div>
     
<style>
   /*
.fixed-call-button {
  position: fixed;
  bottom: 20px; 
  right: 20px; 
  z-index: 9999;
  display: flex;
  align-items: center;
}

.btn-call {
  display: flex;
  align-items: center;
 background-color: green;
  color: white;
  padding: 10px 15px; Padding around the button 
  text-decoration: none;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); 
  margin-bottom: 90px;
}

.btn-call img {
  width: 40px;
  height: auto;
  vertical-align: middle; 
  margin-right: 8px;
}

.btn-call span {
  display: none;
}

@media (max-width: 768px) {
  .fixed-call-button {
    bottom: 10px;
    right: 10px;
    margin-bottom: 17px;
    width: 21%;
  }

  .btn-call {
    padding: 8px 12px;
  }

  .btn-call img {
    width: 18px;
  }

  .btn-call span {
    display: inline;
  }
}

*/
</style>
<div class="container-fluid theme-head ft-bg pt-2 pb-2 footer-link  m-0 p-0">
     <div class="row m-0 p-0">
          <div class="col-xl-3 col-md-3 col-sm-3 col-12  m-0 p-0">
               <div class="row m-0 p-0">
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12 text-center  m-0 p-0">
                         <img alt="footer logo" src="https://templemitra.com/files/assets/images/logofooter.png" class="img-fluid">
                    </div>
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12 text-center footer-address  m-0 p-0">
                         Headquarter : Templemitra.com-(Avichal Srishtisutra Infotainment Pvt. Ltd.), C4, Rayos Building, Sector 63 Rd, C Block, Sector 63, Noida, Uttar Pradesh 201301<br>
                         <p><i class="fas fa-phone footer-s-con"></i> : 0120-4960578 <br>
                             <i class="fas fa-phone-volume"></i> : +91-8851694514<br>
                              
                              <i class="fas fa-phone-volume"></i> : +91-7678398674
                         </p>
                    </div>
               </div>
          </div>
          
          <div class="col-xl-9 col-md-9 col-sm-9 col-12  m-0 p-0">
               <div class="row m-0 p-0">
                    <div class="col-xl-3 col-md-3 col-sm-6 col-6  m-0 p-0">
                         <div class="footer-link-outer">
                              <h5 class="footer-head">
                                   Hot Destinations</h5>
                              <div class="row m-0 p-0">
                                                                           <div class="col-xl-12 col-md-12 col-sm-12 col-12 p-0">
                                             <a class="destination-o" href="https://templemitra.com/holiday-packages/andaman-tour-packages                                             
                                             ">
                                                  Andaman
                                             </a>
                                        </div>
                                        <!--end product 1-->
                                                                           <div class="col-xl-12 col-md-12 col-sm-12 col-12 p-0">
                                             <a class="destination-o" href="https://templemitra.com/temple-tour-packages/chardham-yatra-packages                                             
                                             ">
                                                  Chardham 
                                             </a>
                                        </div>
                                        <!--end product 1-->
                                                                           <div class="col-xl-12 col-md-12 col-sm-12 col-12 p-0">
                                             <a class="destination-o" href="https://templemitra.com/honeymoon-packages/goa-honeymoon-packages                                             
                                             ">
                                                  Goa
                                             </a>
                                        </div>
                                        <!--end product 1-->
                                                                           <div class="col-xl-12 col-md-12 col-sm-12 col-12 p-0">
                                             <a class="destination-o" href="https://templemitra.com/temple-tour-packages/gujarat-tour-packages                                             
                                             ">
                                                  Gujarat 
                                             </a>
                                        </div>
                                        <!--end product 1-->
                                                                           <div class="col-xl-12 col-md-12 col-sm-12 col-12 p-0">
                                             <a class="destination-o" href="https://templemitra.com/honeymoon-packages/himachal-honeymoon-packages                                             
                                             ">
                                                  Himachal
                                             </a>
                                        </div>
                                        <!--end product 1-->
                                                                           <div class="col-xl-12 col-md-12 col-sm-12 col-12 p-0">
                                             <a class="destination-o" href="https://templemitra.com/honeymoon-packages/north-east-honeymoon-packages                                             
                                             ">
                                                  North East
                                             </a>
                                        </div>
                                        <!--end product 1-->
                                                                 </div>
                         </div>
 
                    </div>
                    
                    <div class="col-xl-3 col-md-3 col-sm-2 col-6  m-0 p-0">
                         <div class="footer-link-outer">
                              <h5 class="footer-head">Important Links </h5>
                              <a href="https://templemitra.com/blogs.php">Travel Blog</a>
                              <a href="https://templemitra.com/terms-&-condition.php"> Terms of Service</a>
                              <a href="https://templemitra.com/privacy-policy.php">Privacy Policy </a>
                              <a href="https://templemitra.com/faq.php">FAQ’s</a>
                              <a href="https://templemitra.com/sitemap.xml">Sitemap</a>
                              <a href="https://templemitra.com/share-experience.php">Share Experience</a>

                         </div>
                    </div>
                    <div class="col-xl-3 col-md-3 col-sm-2 col-6  m-0 p-0">
                         <div class="footer-link-outer">
                              <h5 class="footer-head">ABOUT</h5>
                              <a href="https://templemitra.com/about-us.php">About Us</a>
                              <a href="https://templemitra.com/business-enquiry.php">Become Our Partner</a>
                              <a href="https://templemitra.com/we-are-hiring.php">We are Hiring</a>
                              <a href="#" class="md-trigger signIn" data-modal="modal-6">Register with Us</a>
                              <a href="https://templemitra.com/contact-us.php">Contact Us</a>
                              <a href="https://templemitra.com/disclaimer.php">Disclaimer</a>

                         </div>

                    </div>
                    <div class="col-xl-3 col-md-3 col-sm-3 col-6 m-0 p-0">
                         <!-- facebook page -->
                         <iframe class="fb-banner" src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Ftemplemitra%2F&amp;tabs&amp;width=340&amp;height=214&amp;small_header=false&amp;adapt_container_width=true&amp;hide_cover=false&amp;show_facepile=true&amp;appId" width="100%" height="214" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowtransparency="true" allow="encrypted-media"></iframe>
                         <!--  trusted steel-->
                         <div class="row m-0 p-0 m-0">
                              <div class="col-lg-7 col-sm-7 col-md-7 col-7 m-0 p-0 pl-4">
                                   <span id="siteseal">
                                        <script async="" src="https://seal.godaddy.com/getSeal?sealID=q4G7KAggP9dh0R9WQG3FkZBHMdAbizaXPyyav6z17g3xRtBya8j1HXUQd080">
                                        </script>
                                   </span>
                                   <div class="col-lg-12 col-sm-12 col-md-12 col-12 m-0 p-0">
                                        <img class="img-fluid ml-3 mt-2" alt="trust seal image" src="https://templemitra.com/files/assets/images/trust.png">
                                   </div>
                              </div>
                         </div>
                    </div>
               </div>

               <div class="col-xl-6 col-md-6 col-sm-6 col-12 p-0 offset-md-2">
                    <img src="https://templemitra.com/files/assets/images/accept-card.png" class="accept-card img-fluid" alt="visa card">
                    <span id="siteseal">
                         <script async src="https://seal.godaddy.com/getSeal?sealID=q4G7KAggP9dh0R9WQG3FkZBHMdAbizaXPyyav6z17g3xRtBya8j1HXUQd080"></script>
                    </span>
               </div>
          </div>
         
     </div>
     <div class="container text-center">
          <div class="row m-0 p-0">
               <div class="col-sm-12">
                    <h5 class="footer-head h3 text-center my-2">Our Branch Offices</h5>
               </div>

               <div class="col-xl-3 col-md-3 col-sm-2 col-6  m-0 p-0">
                    <h5 class="footer-head h6 text-center my-2">Andaman & Nicobar Islands Office</h5>
                    <p class="text-light px-2"> #17 Chruch Lane Road near Bank of India Phoniexbay, South andaman, Andaman and nicobar Island 744102
                         <br> <b>Email -</b>info@templemitra.com
                    </p>
               </div>

               <div class="col-xl-3 col-md-3 col-sm-2 col-6  m-0 p-0">
                    <h5 class="footer-head h6 text-center my-2">Haridwar ( Uttarakhand ) Office</h5>
                    <p class="text-light px-2"> Himalay Depot, Street No. 2 , Shravan Nath Nagar , Haridwar, Uttarakhand -249401
                         <br> <b>Email -</b>info@templemitra.com
                    </p>
               </div>
               <div class="col-xl-3 col-md-3 col-sm-2 col-6  m-0 p-0">
                    <h5 class="footer-head h6 text-center my-2">Nainital ( Kumaon, Uttarakhand) Office</h5>
                    <p class="text-light px-2"> Om Garage, Near Shri Ram Hospital Tikoniya Haldwani, Nainital-263001 <br> <b>Email -</b>info@templemitra.com </p>
               </div>
               <div class="col-xl-3 col-md-3 col-sm-2 col-6  m-0 p-0">
                    <h5 class="footer-head h6 text-center my-2">Manali ( Himachal Pradesh) Office</h5>
                    <p class="text-light px-2"> Nagger Road, Chotipatlikul,Sarsai, Haripur, Kullu Manali ( H.P)-175136
                         <br> <b>Email -</b> info@templemitra.com
                    </p>
               </div>
               <div class="col-xl-3 col-md-3 col-sm-2 col-6  m-0 p-0">
                    <h5 class="footer-head h6 text-center my-2">Siliguri, Darjeeling ( W.B. & North East ) Office</h5>
                    <p class="text-light px-2"> Ground Floor, Hill Tower Apartment , Besidse MP Lodge
                         Pradhan Nagar ,Siliguri, Darjeeling , West Bengal - 734003
                         <br> <b>Email -</b>info@templemitra.com
                    </p>
               </div>
               <div class="col-xl-3 col-md-3 col-sm-2 col-6  m-0 p-0">
                    <h5 class="footer-head h6 text-center my-2">Ahmedabad, Gujarat Office</h5>
                    <p class="text-light px-2"> 16/1 Vallabhapark Shopping Center , Vallabhpark, D- cabin, Sabarmati , Ahmedabad -380005
                         <br> <b>Email -</b> info@templemitra.com
                    </p>
               </div>
               <div class="col-xl-3 col-md-3 col-sm-2 col-6  m-0 p-0">
                    <h5 class="footer-head h6 text-center my-2">Madurai( Tamilnadu ) Office</h5>
                    <p class="text-light px-2"> 3/370-A, Meenatchi Nagar, Thirumangalam, Main Road
                         Thanakkankulam, Madurai, Tamilnadu-625006
                         <br> <b>Email -</b>info@templemitra.com
                    </p>
               </div>
               <div class="col-xl-3 col-md-3 col-sm-2 col-6  m-0 p-0">
                    <h5 class="footer-head h6 text-center my-2">Kolkata Office</h5>
                    <p class="text-light px-2"> 4/A:Ekka road,
                         Near Seeraj Golden Restaurant, Park Circus, Kolkata -700020
                         <br> <b>Email -</b>info@templemitra.com
                    </p>
               </div>


          </div>
     </div>
</div>

<div class="container-fluid theme-head theme-bg">
     <div class="footer-address">
          <div class="row m-0 p-0" style="color:#fd7e14;">
               <div class="col-xl-2 col-md-6 col-sm-6 col-6 m-0 p-0 shadow">
                  <a class="text-ligh" href="https://templemitra.com/business-enquiry.php" style="color: #fd7e14;">
                        <i class="fas fa-plus-circle text-warnin" style="color: #fd7e14;"></i> Business With Us

                    </a>


               </div>
               <div class="col-xl-2 col-md-6 col-sm-6 col-6 m-0 p-0">
                    <a class="text-ligh" style="color: #fd7e14;" href="https://templemitra.com/contact-us.php"> <i class="fas fa-mobile-alt text-warnin"></i> Contact Us </a>
               </div>
               <div class="col-xl-4 col-md-2 col-sm-6 col-12  m-0 p-0 text-center">
                    © 2017 Templemitra.com
               </div>

               <div class="col-xl-4 col-md-2 col-sm-6 col-12" >
                    <span>Follow Us</span>
                 <!-- <img src="https://templemitra.com/files/assets/images/footer_arrow.png" alt="aerrow png"> -->

                    <a href="https://www.facebook.com/TempleMitra/" target="_blank" class="btn btn-facebook btn-icon-social text-center"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://twitter.com/temple_mitra" target="_blank" class="btn btn-twitter btn-icon-social"><i class="fab fa-twitter"></i>
                    </a>
                    <a href="https://www.youtube.com/channel/UCHSnR1kw9x36IXL9c-iAUfg" target="_blank" class="btn btn-twitter btn-icon-social"><i class="fab fa-youtube"></i>
                    </a>

                    <a href="https://www.instagram.com/temple_mitra/" target="_blank" class="btn btn-twitter btn-icon-social"><i class="fab fa-instagram"></i>
                    </a>
                    
                    
                    
                    
                    <div class="wtp-chat">
                         <a href="https://api.whatsapp.com/send?phone=918851694514&amp;text= Package Details">
                              <span>ASK 24X7 </span>
                              <img class="img-fluid" src="https://templemitra.com/files/assets/images/whats-app-chat.png" alt="whats'app templemitra">
                         </a>
                         
                    </div>
                    
               </div>
          </div>
     </div>
</div>
<!--
<div class="fixed-call-button">
  <a href="tel:+918851694514" class="btn btn-call">
       
     <img class="img-fluid" src="https://templemitra.com/files/assets/images/whats-app-chat.png" alt="whats'app templemitra">Call 24X7
                         </a>
</div>
-->
<!--  modal-->
<div class="md-modal md-effect-10 p-0" id="modal-10">
     <div class="md-content bg-light">
          <h3>Get a Free Quote..
               <!-- end /.footer -->
               <span class="waves-effect md-close">X</span>
          </h3>


          <div class="j-pro" id="j-pro" >
               <div class="j-content">
                    <!-- start name -->
                    <div class="j-row pl-2 pr-2">
                         <div class="j-span6 j-unit p-0">
                              <div class="j-input">
                                   <label class="j-icon-right" for="name">
                                        <i class="fas fa-user"></i>
                                   </label>
                                   <input type="text" id="name" name="name" placeholder="Enter Name*">
                                   <span class="j-tooltip j-tooltip-right-top">Enter Name*</span>
                              </div>
                         </div>



                         <div class="j-span6 j-unit p-0">
                              <div class="j-input">
                                   <label class="j-icon-right" for="phone">
                                        <i class="fas fa-phone-alt"></i>
                                   </label>
                                   <input type="text" id="phone" name="phone" placeholder=" Enter Mobile No.*"  maxlength="12"  minlength="10" required>
                                   <span class="j-tooltip j-tooltip-right-top">
                                        Enter Mobile No.*
                                   </span>
                              </div>
                         </div>
                    </div>

                    <!-- end name -->
                    <!-- start email phone -->
                    <div class="j-row pl-2 pr-2">
                         <div class="j-span12 j-unit p-0">
                              <div class="j-input">
                                   <label class="j-icon-right" for="email">
                                        <i class="fas fa-envelope-open-text"></i>
                                   </label>
                                   <input type="email" id="email" name="email" placeholder="Enter Email Id">
                                   <span class="j-tooltip j-tooltip-right-top">Enter Email Id</span>
                              </div>
                         </div>
                         <div class="j-span12 j-unit p-0">
                              <div class="j-unit">
                                   <div class="j-input">
                                        <label class="j-icon-right" for="name">
                                             <i class="fas fa-map-marker-alt"></i>
                                        </label>
                                        <input class="my-package" type="text" id="my-package" placeholder="Enter Destination">
                                        <span class="j-tooltip j-tooltip-right-top">Enter Destination</span>
                                   </div>
                              </div>
                         </div>
                    </div>
                    <!-- end email phone -->
                    <!-- start -->
                    <div class="j-row pl-2 pr-2">
                         <div class="j-span6 j-unit p-0">
                              <label class="j-label">Adults</label>
                              <div class="j-input">
                                   <label class="j-icon-right" for="adults">
                                        <i class="fas fa-user"></i>
                                   </label>
                                   <input type="number" id="adults" name="adults" placeholder="No of Adults (12+ yr)">
                                   <span class="j-tooltip j-tooltip-right-top">No. of adult</span>
                              </div>
                         </div>
                         <div class="j-span6 j-unit p-0">
                              <label class="j-label">Children</label>
                              <div class="j-input">
                                   <label class="j-icon-right" for="children">
                                        <i class="fas fa-user"></i>
                                   </label>
                                   <input type="number" id="children" name="children" placeholder="No Of child (6 to 11 yr)">
                                   <span class="j-tooltip j-tooltip-right-top">No. of children</span>
                              </div>
                         </div>
                    </div>
                    <!-- end -->
                    <!-- start message -->
                    <div class="j-unit">
                         <label class="j-label mt-1">Additional Information ( Optional ) </label>
                         <div class="j-input">
                              <textarea id="message" spellcheck="false" cols="5" name="message" placeholder="your message"></textarea>
                         </div>
                    </div>
                    <!-- end message -->
                    <!-- start response from server -->
                    <div class="j-response"></div>
                    <!-- end response from server -->
               </div>
               <input class="form-control get-i" type="hidden" />
               <!-- end /.content -->
               <div class="d-flex justify-content-center">
                    <span class="loading">
                         <img class="img-fluid " src="https://templemitra.com/files/assets/images/loading.gif" alt="loading bar gif"> Please Wait..here 
                    </span>
               </div>
               <div class="j-footer">

                    <button type="submit" class="btn btn-primary send-enq pt-3 pb-3 pl-4 pr-4">Send</button>
               </div>
               <div id="alt"></div>
          </div>
     </div>
</div>


<!--  modal-->
<!-- Login modal-->
<div class="md-modal md-effect-6 p-2" id="modal-6">
     <div class="md-content log-content text-light">
          <h3 class="bg-login-h">Login <span>|</span> Sign Up
               <!-- end /.footer -->
               <span class="waves-effect md-close">X</span>
          </h3>
          <div class="d-flex justify-content-center">
               <div class="log-outer">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs lg-tabs b-none p-0" role="tablist">
                         <li class="nav-item">
                              <a class="nav-link log" data-toggle="tab" href="#signIn" role="tab" aria-expanded="false" aria-selected="true">Login</a>
                              <div class="slide"></div>
                         </li>
                         <li class="nav-item">
                              <a class="nav-link reg" data-toggle="tab" href="#signup" role="tab" aria-expanded="false">Sign Up</a>
                              <div class="slide"></div>
                         </li>
                         <li class="nav-item">
                              <a class="nav-link forg" data-toggle="tab" href="#forget" role="tab" aria-expanded="false">Forget Password</a>
                              <div class="slide"></div>
                         </li>
                    </ul>
                    <!-- Tab panes -->
                    <div class="tab-content tabs-left-content card-block">
                         <div class="tab-pane active" id="signIn" role="tabpanel" aria-expanded="false">
                              <div class="auth-box  p-2">
                                   <div class="d-flex justify-content-center">
                                        <img class="img-fluid w-25" src="https://templemitra.com/files/assets/images/avtar2.png" alt="avtar png image for login form">
                                   </div>
                                   <div class="form-group form-primary">
                                        <input type="text" id="l-email" class="p-2 w-100" required="" placeholder="Email Or User Name">
                                        <span class="form-bar"></span>
                                   </div>
                                   <div class="form-group form-primary">
                                        <input type="password" autocomplete="new-password" id="l-password" class="p-2 w-100" required="" placeholder="Password ">
                                        <span class="form-bar"></span>
                                   </div>

                                   <div class="checkbox-fade fade-in-primary d-">
                                        <label>
                                             <input type="checkbox" id="set">
                                             <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                                             <span class="text-inverse">Remember me</span>
                                        </label>
                                   </div>

                                   <div class="d-flex justify-content-end">
                                        <a href="#" class="f-w-600 forg  text-light"> Forgot
                                             Password?</a>
                                   </div>
                                   <div class="text-center d-block" id="l-alert"></div>
                                   <input type="button" id="log" class="btn btn-primary pl-5 pr-5 pt-2 pb-2 border-0" value="Login">
                              </div>
                              <!-- end of form -->
                         </div>
                         <div class="tab-pane" id="signup" role="tabpanel" aria-expanded="false">
                              <!-- Signup  -->
                              <div id="sign-alert"></div>
                              <div id="user-sign" class=" p-2">
                                   <div class="r-email">
                                        <input type="text" class="mt-1 p-1 w-100" id="user_name" placeholder="User Name">
                                        <span class="user_check"></span><br>
                                   </div>
                                   <div class="r-email">
                                        <input type="email" class="mt-1 p-1 w-100" id="s-email" placeholder="Enter Email">
                                        <span class="user_email"></span>
                                   </div>
                                   <div class="m-number">
                                        <input type="number" minlength="10" maxlength="10" pattern="[0][0-9]" class="mt-1 p-1 w-100" id="s-phone" placeholder="Enter Mobile Number">
                                        <span class="messages"></span>
                                   </div>
                                   <div class="r-password">
                                        <input type="password" autocomplete="new-password" id="s-password" class="mt-1 p-1 w-100" placeholder="Enter Password (At least 8 characters)">
                                        <span class="c-password"></span>
                                   </div>
                                   <div class="r-password">
                                        <input type="password" autocomplete="new-password" id="repeat-password" class="mt-1 p-1 w-100" placeholder="Re Enter Password (At least 8 characters)">
                                        <span class="r-c-password"> </span>
                                   </div>
                                   <span class="log-alt"></span>
                                   <div class="row m-0 p-0 m-t-30">
                                        <div class="col-md-12">
                                             <input type="button" id="signUp" class="btn btn-primary btn-md btn-block waves-effect text-center mt-1 p-2" value="Sign up">
                                        </div>
                                   </div>
                              </div>
                         </div>
                         <br>
                    </div>

                    <div class="tab-pane" id="forget" role="tabpanel" aria-expanded="false">
                         <!-- Signup  -->
                         <div class="md-float-material form-material forgt-password p-2">
                              <div class="form-group form-primary">
                                   <input type="text" id="email-address" class="mt-1 p-1 w-100" required="" placeholder="Your Email Address">
                                   <span class="form-bar"></span>
                              </div>
                              <div class="check"></div>
                              <div class="row m-0 p-0">
                                   <div class="col-md-12">
                                        <div class="d-flex justify-content-center">
                                             <img class="img-fluid loading" src="https://templemitra.com/files/assets/images/loading.gif" alt="loading gif">
                                        </div>
                                        <input type="button" class="btn btn-primary btn-md btn-block waves-effect text-center m-b-20 forget-pass" value="Reset Password">
                                   </div>

                              </div>
                              <div id="get-password"></div>
                         </div>
                         <br>
                    </div>


               </div>
          </div>
     </div>
</div>

<script type="text/javascript" src="https://templemitra.com/files/assets/js/custom.js"></script>
<script>
    //  eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('3(1h).S(b(){3("d, g").h("13 12 j",b(e){e.J()});3("d[f=\'I\']").11(\'10\',b(s){8 t=s.Y;l(t>=X&&t<=W){s.J()}});3("d[f=\'y\']").E(b(){8 L=/^[A-r-9.V%+-]+@([A-r-9-]+\\.)+[A-Z]{2,4}$/i;l(L.u(7.U)){T.Q(\'R\')}K{v(\'P N\');$("d[f=\'y\']").6(\'\')}});3("g").E(b(){8 M=3(\'g\').6();l(/(O|14|17):\\/\\/[a-D-9]+([\\-\\.]{1}[a-D-9]+)\\.[a-z]{2,5}(:[0-9]{1,5})?(\\/.)?$/i.u($(7).6())){v(\'H G F\');3(\'g\').6(\'\')}K l(/^[a-1m-r-9\\-\\.]+\\.(1l|1k|16|1j|1i|18|1g|1f|1e|1d)$/i.u(3(7).6())){v(\'H G F\');3(\'g\').6(\'\')}});8 C=1c;3(\'p\').h(\'o j\',\'g\',b(){3(7).6(3(7).6().q(0,C));8 c=3(7).6().m;n=C-k(c)});8 w=1b;3(\'p\').h(\'o j\',"d[f=\'I\']",b(){3(7).6(3(7).6().q(0,w));8 c=3(7).6().m;n=w-k(c)});8 B=15;3(\'p\').h(\'o j\',"d[f=\'1a\']",b(){3(7).6(3(7).6().q(0,B));8 c=3(7).6().m;n=B-k(c)});8 x=19;3(\'p\').h(\'o j\',"d[f=\'y\']",b(){3(7).6(3(7).6().q(0,x));8 c=3(7).6().m;n=x-k(c)})});',62,85,'|||jQuery|||val|this|var|||function|tlength|input||type|textarea|on||paste|parseInt|if|length|remain|keyup|body|substring|Z0|event|key|test|alert|textLimit|nemailLimit|email|||numLimit|maxchars|z0|blur|Allowed|Not|Links|text|preventDefault|else|testEmail|message|Email|http|Wrong|log|passed|ready|console|value|_|57|48|which||keydown|bind|copy|cut|https||net|ftp|COM|60|number|30|100|EDU|MIL|NET|ORG|document|edu|mil|org|com|zA'.split('|'),0,{}))

</script>

<script>
    document.addEventListener('scroll', function() {
  var callButton = document.querySelector('.fixed-call-button');
  if (window.scrollY > 300) { // Adjust scroll position as needed
    callButton.classList.add('visible');
  } else {
    callButton.classList.remove('visible');
  }
});

</script>
     <!-- modalEffects js nifty modal window effects -->
<script type="text/javascript" src="https://templemitra.com/files/assets/js/modalEffects.js"></script>
<script type="text/javascript" src="https://templemitra.com/files/assets/js/classie.js"></script>
<!--signIn  modal-->
<!--java script    -->
<input type="hidden"   id="user_location">

<!-- Custom js -->
<script src="https://templemitra.com/files/assets/js/ads-foo.js"></script>
<script>
     $(document).ready(function() {
          $(document).on('click', '.send-enq', function() {
               var myParam = window.location.href;
               var name = $("#name").val();
               var phone = $("#phone").val();
               var email = $("#email").val();
               var adults = $("#adults").val();
               var children = $("#children").val();
               var my_package = $("#my-package").val();
               var message = $("#message").val();
               var page = myParam;
               var location = $("#user_location").val();
               var get_i = $(".get-i").val();

               if (name == '') {
                    $("#name").focus();
                    $("#name").addClass('border-danger');
               } else {
                    if (phone.length <= 9) {
                         $("#name").removeClass('border-danger');

                         $("#phone").focus();
                         $("#phone").addClass('border-danger');
                    } else {
                         var email = $('#email').val();
                         var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;

                         if (email != '' && !emailReg.test(email)) {
                              //  email veryfy  
                              $("#email").focus();
                              $("#email").addClass('border-danger');
                              $("#phone").removeClass('border-danger');

                         } else {
                              if (my_package == '') {
                                   $("#phone").removeClass('border-danger');
                                   $("#email").removeClass('border-danger');
                                   $("#phone").removeClass('border-danger');
                                   $("#my-package").focus();
                                   $("#my-package").addClass('border-danger');
                              } else {
                                   if (phone != '' && name != '' && my_package != '') {
                                        $("#my-package").removeClass('border-danger');
                                        $(".loading").show();

                                        $.ajax({
                                             type: "POST",
                                             url: "https://templemitra.com/files/form/send-enquiry.php",
                                             data: {
                                                  name: name,
                                                  email: email,
                                                  phone: phone,
                                                  adults: adults,
                                                  children: children,
                                                  my_package: my_package,
                                                  message: message,
                                                  location: location,
                                                  get_i: get_i,
                                                  page: page
                                             },
                                             success: function(data) {
                                                  $('#alt').fadeIn().html('</span>' + data + '</span>');
                                                  $(".loading").hide();
                                                  $("#name,#email,#phone,#adults,#children,#message").val("");
                                                  $("#name,#email,#phone,#adults,#children,#message").removeClass('border-danger');
                                                  setInterval(function() {
                                                       $('#alt').hide();
                                                  }, 5000);
                                             }

                                        });
                                   }
                              }
                         }
                    }
               }
          });


          $(document).on('click', '.enquiry-btn', function() {
               var element = $(this);
               var data_package = element.attr('my-package');
               var p_id = element.attr('p-id');
               $("#my-package, .my-package").val(data_package);
               $(".get-i").val(p_id);

          });

          $(document).on('click', '.send-enq-t', function() {

               var url = window.location.href;
               var myParam = url.substring(url.lastIndexOf('/') + 1)
               var name = $("#name-t").val();
               var email = $("#email-t").val();
               var phone = $("#phone-t").val();
               var adults = $("#adults-t").val();
               var children = $("#children-t").val();
               var my_package = $("#my-package-t").val();
               var message = $("#message-t").val();
               var page = myParam;
               var location = $("#user_location").val();

               if (name == '') {
                    $("#name-t").focus();
                    $("#name-t").addClass('border-danger');
               } else {
                    if (phone.length <= 9) {
                         $("#name-t").removeClass('border-danger');
                         $("#phone-t").focus();
                         $("#phone-t").addClass('border-danger');
                    } else {
                         var email = $('#email-t').val();
                         var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;

                         if (email != '' && !emailReg.test(email)) {
                              //  email veryfy  
                              $("#email-t").focus();
                              $("#email-t").addClass('border-danger');
                              $("#phone-t").removeClass('border-danger');

                         } else {
                              if (my_package == '') {
                                   $("#phone-t").removeClass('border-danger');
                                   $("#email-t").removeClass('border-danger');
                                   $("#phone-t").removeClass('border-danger');
                                   $("#my-package-t").focus();
                                   $("#my-package-t").addClass('border-danger');
                              } else {
                                   if (phone != '' && name != '' && my_package != '') {
                                        $(".loading-t").show();
                                        $("#my-package-t").removeClass('border-danger');
                                        $.ajax({
                                             type: "POST",
                                             url: "https://templemitra.com/files/form/send-enquiry.php",
                                             data: {
                                                  name: name,
                                                  email: email,
                                                  phone: phone,
                                                  adults: adults,
                                                  children: children,
                                                  my_package: my_package,
                                                  message: message,
                                                  location: location,
                                                  page: page,
                                             },
                                             success: function(data) {
                                                  $('#alt-t').fadeIn().html('</span>' + data + '</span>');
                                                  $(".loading-t").hide();
                                                  $("#name-t,#email-t,#phone-t,#adults-t,#children-t, #my-package-t,#message-t").val("");

                                                  $("#name-t,#email-t,#phone-t,#adults-t,#children-t, #my-package-t,#message-t").removeClass('border-danger');;
                                                  setInterval(function() {
                                                       $('#alt-t').hide();
                                                  }, 5000);
                                             }
                                        });


                                   }

                              }
                         }
                    }
               }
          });
          
          
          
          // for emi form start
          
          
$(document).on('click', '.emi-send-enq-t', function() {
    var url = window.location.href;
    var myParam = url.substring(url.lastIndexOf('/') + 1);
    var name = $("#eminame-t").val();
    var phone = $("#emiphone-t").val();
    var pancard = $("#emipancard").val();
    var message = $("#emimessage-t").val();
    var page = myParam;
     
    // Ensure missing fields are sent as null
    if (name == '') {
        name = null;
    }
    if (phone == '') {
        phone = null;
    }
    if (pancard == '') {
        pancard = null;
    }
    if (message == '') {
        message = null;
    }

    // Name validation: Only text (letters and spaces)
    var namePattern = /^[A-Za-z\s]+$/;
    if (name == null || !namePattern.test(name)) {
        $("#eminame-t").focus();
        $("#eminame-t").addClass('border-danger');
        alert("Please enter a valid name (letters and spaces only).");
        return;
    } else {
        $("#eminame-t").removeClass('border-danger');
    }

    // Phone number validation: Only numbers, exactly 10 digits
    var phonePattern = /^[0-9]{10}$/;
    if (phone == null || !phonePattern.test(phone)) {
        $("#emiphone-t").focus();
        $("#emiphone-t").addClass('border-danger');
        alert("Please enter a valid phone number (10 digits only).");
        return;
    } else {
        $("#emiphone-t").removeClass('border-danger');
    }

    // PAN card validation: Alphanumeric, with both numbers and letters
    var pancardPattern = /^[A-Za-z0-9]+$/;
    if (pancard == null || !pancardPattern.test(pancard)) {
        $("#emipancard").focus();
        $("#emipancard").addClass('border-danger');
        alert("Please enter a valid PAN card number (letters and numbers only).");
        return;
    } else {
        $("#emipancard").removeClass('border-danger');
    }

    // If all fields are valid, submit via AJAX
    $.ajax({
        type: "POST",
        url: "https://templemitra.com/files/form/emi-enquery.php",
        data: {
            name: name,
            phone: phone,
            pancard: pancard,
            message: message,
            page: page,
        },
        success: function(data) {
            // Show success alert message
            alert("Success: Your EMI eligibility inquiry has been submitted successfully!");

            // Clear form fields and reset styles
            $("#eminame-t, #emiphone-t, #emipancard, #emimessage-t").val("");
            $("#eminame-t, #emiphone-t, #emipancard").removeClass('border-danger');
        },
        error: function(xhr, status, error) {
            alert("Error: " + error); // Error alert if the request fails
        }
    });
});








          
            // for emi form end

          //  location         
       
          // wishlist 
          // add item to cart
          $("#shopping-cart-results").load("https://templemitra.com/cart.php");
          $(".product-form").submit(function(e) {
               var form_data = $(this).serialize();
               var button_content = $(this).find('button[type=submit]');
               button_content.html('<i class="fas fa-heart f-20 text-success"></i>');
               $.ajax({
                    url: "https://templemitra.com/manage_cart.php",
                    type: "POST",
                    dataType: "json",
                    data: form_data
               }).done(function(data) {
                    $("#cart-container").html(data.products);
                    $("#shopping-cart-results").load("https://templemitra.com/cart.php");
                    button_content.html('<i class="fas fa-heart f-20 text-success"></i>');
               })
               e.preventDefault();
          });
          //Remove items from cart
          $("#shopping-cart-results").on('click', '.remove-item', function(e) {
               e.preventDefault();
               var pcode = $(this).attr("data-code");
               $(this).parent().parent().fadeOut();
               $.getJSON("https://templemitra.com/manage_cart.php", {
                    "remove_code": pcode
               }, function(data) {
                    $("#cart-container").html(data.products);
                    $("#shopping-cart-results").load("https://templemitra.com/cart.php");
               });
          });
     });
</script>
<script>
  window.addEventListener('load', function() {
    if (window.location.pathname == '/gujarat-trip-package') {
      var x = 0;
      var timer = setInterval(function() {
        if (jQuery('.enquiry_success').is(':visible')) {
          if (x == 0) {
            gtag('event', 'conversion', {
              'send_to': 'AW-11091917885/TWagCPGl6vQYEL34hKkp'
            });
            x = 1;
          }
          clearInterval(timer)
        }
      })
    }
  })
</script>
<script>
  window.addEventListener('load', function() {
    if (window.location.pathname == '/chardham-tour-package') {
      var x = 0;
      var timer = setInterval(function() {
        if (jQuery('.enquiry_success').is(':visible')) {
          if (x == 0) {
            gtag('event', 'conversion', {
              'send_to': 'AW-11091137404/iQB2CPmQyYsYEPym1agp'
            });
            x = 1;
          }
          clearInterval(timer)
        }
      })
    }
  })
</script>

<script>
  window.addEventListener('load', function() {
    if (window.location.pathname == '/goa-tour-package') {
      var x = 0;
      var timer = setInterval(function() {
        if (jQuery('.enquiry_success').is(':visible')) {
          if (x == 0) {
            gtag('event', 'conversion', {
              'send_to': 'AW-11279859446/DlLCCLqPgfsYEPb904Iq'
            });
            x = 1;
          }
          clearInterval(timer)
        }
      })
    }
  })
</script>

<!--Update-->

<script>
  window.addEventListener('load',function(){
    var formTimer = setInterval(function(){
      if(jQuery('.enquiry_success').is(':visible')){
        gtag('event', 'conversion', {'send_to': 'AW-11338038065/550nCPu1s_wYELH2sp4q'});
        clearInterval(formTimer);
      }
    },1000);
  });
</script>

<script>
  window.addEventListener('load',function(){
    var formTimer = setInterval(function(){
      if(jQuery('.enquiry_success').is(':visible')){
        gtag('event', 'conversion', {'send_to': 'AW-11279823976/JrUgCMfrtfwYEOjo0YIq'});
        clearInterval(formTimer);
      }
    },1000);
  });
</script>

<script>
  window.addEventListener('load',function(){
    var formTimer = setInterval(function(){
      if(jQuery('.enquiry_success').is(':visible')){
        gtag('event', 'conversion', {'send_to': 'AW-11395584087/3x8CCLalv_IYENeg67kq'});
        clearInterval(formTimer);
      }
    },1000);
  });
</script>

     <!-- modalEffects js nifty modal window effects -->
     <script type="text/javascript" src="https://templemitra.com/files/assets/js/modalEffects.js"></script>
     <script type="text/javascript" src="https://templemitra.com/files/assets/js/classie.js"></script>
</body>

<script>'undefined'=== typeof _trfq || (window._trfq = []);'undefined'=== typeof _trfd && (window._trfd=[]),_trfd.push({'tccl.baseHost':'secureserver.net'},{'ap':'cpsh-oh'},{'server':'sg2plzcpnl504231'},{'dcenter':'sg2'},{'cp_id':'10045442'},{'cp_cl':'8'}) // Monitoring performance to make your website faster. If you want to opt-out, please contact web hosting support.</script><script src='https://img1.wsimg.com/traffic-assets/js/tccl.min.js'></script></html>

