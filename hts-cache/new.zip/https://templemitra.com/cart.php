                               
                               
                                            <div class='w-100'>
                                            <div class='wish-empty'> 
                                            <a href='/'>
                                            <img src='https://templemitra.com/files/assets/images/icn/smile-original.gif'>
                                            </a>
                                            <h5>Your Cart is empty</h5>
                                            </div>
                                            </div>
                                            
                                <script>
                                  $(document).on('click','.enquiry-btn',function(){
                                    $(".md-effect-10").addClass("md-show");
                                    var element = $(this);
                                    var package =element.attr("my-package");
                                    $("#my-package").val(package);
                                  });
                                </script>

                                